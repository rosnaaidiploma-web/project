# Troubleshooting Guide - HRM System

## 🔍 Common Errors and Solutions

This guide provides solutions for common errors encountered when running the HRM system.

---

## 1. File & Path Errors

### Error: "FileNotFoundError: [Errno 2] No such file or directory"

**Symptoms:**
- System crashes when trying to load data files
- Message shows file path that doesn't exist

**Log Example:**
```
ERROR - [ml_model.py:120] - [MLModel] Error reading CSV file: File not found at data/old_resume_dataset.csv
```

**Solutions:**

**Step 1:** Verify data files exist
```bash
# In VS Code terminal
ls data/
# Should show: employee_dataset.csv, job_dataset.csv, old_resume_dataset.csv
```

**Step 2:** Check working directory
```python
import os
print(os.getcwd())  # Should show path to project root
```

**Step 3:** Update file paths if needed
```python
# In web_app/app.py, ensure DATA_DIR is correct
DATA_DIR = os.path.join(BASE_DIR, "data")  # Correct

# Not this:
DATA_DIR = "data"  # Can cause path issues
```

**Prevention:**
- Always use absolute paths or os.path.join()
- Validate file existence before use:
```python
if not os.path.exists(file_path):
    raise FileNotFoundError(f"File not found: {file_path}")
```

---

### Error: "PermissionError: [Errno 13] Permission denied"

**Symptoms:**
- Cannot write to directory
- Reports not being generated
- Logs not being created

**Log Example:**
```
ERROR - [pdf_report.py:75] - Permission denied when writing to reports/resume_report.pdf
```

**Solutions:**

**For Windows:**
```bash
# Right-click folder → Properties → Security → Edit
# Grant full permissions to your user account
```

**For Linux/Mac:**
```bash
# Fix permissions
chmod 755 logs/
chmod 755 reports/
chmod 755 models/
```

**In Python:**
```python
import os
os.makedirs(directory, mode=0o755, exist_ok=True)  # Creates with proper permissions
```

---

## 2. Data Processing Errors

### Error: "DataValidationError: DataFrame is empty"

**Symptoms:**
- No data being processed
- Model training fails with empty dataset

**Log Example:**
```
ERROR - [data_preprocessing.py:80] - DataValidationError: Dataset is empty
```

**Solutions:**

**Check CSV file format:**
```python
import pandas as pd
df = pd.read_csv("data/old_resume_dataset.csv")
print(df.head())  # Shows first 5 rows
print(df.shape)   # Shows (rows, columns)
print(df.columns) # Shows column names
```

**Ensure required columns exist:**
```python
required_cols = ["Name", "Skills", "Experience", "Education", "Selected"]
missing = [col for col in required_cols if col not in df.columns]
if missing:
    print(f"Missing columns: {missing}")
```

**Check for header row:**
```python
# CSV must have header
# Correct:
Name,Skills,Experience,Education,Selected
John,Python,5,BS,1

# Incorrect (no header):
John,Python,5,BS,1
```

---

### Error: "ValueError: cannot convert float NaN to integer"

**Symptoms:**
- Error when converting Experience column
- NaN values not handled

**Log Example:**
```
ERROR - [data_preprocessing.py:150] - Error converting experience to numeric
```

**Solutions:**

```python
# GOOD: Handle NaN values
df["Experience"] = pd.to_numeric(df["Experience"], errors="coerce").fillna(0).astype(int)

# BAD: Direct conversion fails on NaN
df["Experience"] = df["Experience"].astype(int)  # CRASHES on NaN
```

**Inspect problematic data:**
```python
# Find rows with issues
print(df[df["Experience"].isna()])

# Or fill with defaults
df["Experience"].fillna(0, inplace=True)
```

---

## 3. Machine Learning Errors

### Error: "ModelError: Model file not found at models/model.pkl"

**Symptoms:**
- Cannot make predictions
- Model hasn't been trained yet
- Wrong model path

**Log Example:**
```
ERROR - [ml_model.py:250] - Model file not found at models/model.pkl
```

**Solutions:**

**Step 1:** Check if model exists
```bash
ls models/
# Should show: model.pkl
```

**Step 2:** Train the model first
```bash
# Option A: Run pipeline
python -m src.run_pipeline

# Option B: Use web interface
# Navigate to http://localhost:5000/hr
# Click "Train Model" button
```

**Step 3:** Verify model path is correct
```python
# In web_app/app.py
MODEL_PATH = os.path.join(BASE_DIR, "models", "model.pkl")
print(f"Model path: {MODEL_PATH}")
print(f"Model exists: {os.path.exists(MODEL_PATH)}")
```

---

### Error: "sklearn.exceptions.NotFittedError: Model has not been fitted yet"

**Symptoms:**
- Model exists but cannot make predictions
- Model is corrupted or incomplete

**Log Example:**
```
ERROR - [ml_model.py:300] - Model has not been fitted yet
```

**Solutions:**

```python
# Solution 1: Retrain the model
from src.ml_model import train_resume_model
results = train_resume_model("data/old_resume_dataset.csv", 
                             save_path="models/model.pkl")

# Solution 2: Delete corrupted model and retrain
import os
if os.path.exists("models/model.pkl"):
    os.remove("models/model.pkl")
# Then retrain
```

---

## 4. NLP & Text Processing Errors

### Error: "LookupError: NLTK Data not found"

**Symptoms:**
- Error on first run with text processing
- Missing NLTK corpora

**Log Example:**
```
WARNING - [data_preprocessing.py:40] - Downloading NLTK data...
```

**Solutions:**

```python
# Solution 1: Auto-download (system does this)
# On first run, the system automatically downloads required NLTK data

# Solution 2: Manual download in Python console
import nltk
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('averaged_perceptron_tagger')

# Solution 3: Check NLTK data location
import nltk
print(nltk.data.path)  # Shows where data is stored
```

---

### Error: "ResumeAnalysisError: Resume text is empty"

**Symptoms:**
- No resume data being processed
- Empty string passed to analyzer

**Solutions:**

```python
# Always validate before processing
if not resume_text or not resume_text.strip():
    raise ResumeAnalysisError("Resume text is empty")

# Check input:
print(f"Resume length: {len(resume_text)}")
print(f"Resume (first 100 chars): {resume_text[:100]}")
```

---

## 5. PDF Report Generation Errors

### Error: "PDFReportError: Failed to create PDF"

**Symptoms:**
- Reports not being generated
- Error saving PDF file

**Log Example:**
```
ERROR - [pdf_report.py:75] - Failed to create PDF: Permission denied
```

**Solutions:**

**Step 1:** Ensure ReportLab is installed
```bash
pip install reportlab
```

**Step 2:** Verify reports directory
```python
import os
os.makedirs("reports", exist_ok=True)
os.makedirs("reports", mode=0o755, exist_ok=True)  # With permissions
```

**Step 3:** Check file naming
```python
# Ensure filename is valid
filename = "resume_report.pdf"
if not filename.endswith(".pdf"):
    filename += ".pdf"
```

---

### Error: "reportlab.lib.utils.ImageReader: Cannot identify image"

**Symptoms:**
- Error adding images to PDF
- Image file not found or invalid

**Solutions:**

```python
# Make sure image path is correct
from reportlab.lib.utils import ImageReader

# Valid:
img = ImageReader("path/to/image.png")

# Invalid:
img = ImageReader("invalid_path")  # Fails

# Always check file exists:
if not os.path.exists(image_path):
    log_warning("Image not found, skipping image")
```

---

## 6. Chatbot Errors

### Error: "ChatbotError: Intents file not found"

**Symptoms:**
- Chatbot not responding
- Intents JSON missing

**Log Example:**
```
ERROR - [chatbot.py:45] - Intents file not found at chatbot/intents.json
```

**Solutions:**

**Step 1:** Verify intents.json exists
```bash
ls chatbot/
# Should show: intents.json
```

**Step 2:** Check intents.json format
```bash
# View file
cat chatbot/intents.json

# Should contain valid JSON
```

**Step 3:** Validate JSON syntax
```bash
# In VS Code, open intents.json
# Check for syntax errors (yellow wavy lines)
# Must have valid JSON structure
```

---

### Error: "json.JSONDecodeError: Expecting value"

**Symptoms:**
- Invalid JSON in intents file
- Corrupted intents.json

**Solutions:**

```python
# Validate JSON
import json

with open("chatbot/intents.json", "r") as f:
    try:
        data = json.load(f)
        print("JSON is valid")
    except json.JSONDecodeError as e:
        print(f"JSON Error: {e}")
        print(f"Line {e.lineno}, Col {e.colno}")
```

**Fix JSON:**
- Remove trailing commas
- Ensure all strings use double quotes
- Verify opening/closing braces match

---

## 7. Flask Web Application Errors

### Error: "jinja2.exceptions.TemplateNotFound: index.html"

**Symptoms:**
- Web pages not loading
- 404 or template error

**Log Example:**
```
ERROR - [app.py:150] - TemplateNotFound: index.html
```

**Solutions:**

**Step 1:** Verify templates directory
```bash
ls web_app/templates/
# Should show: index.html, candidate_dashboard.html, etc.
```

**Step 2:** Check Flask template path
```python
# In web_app/app.py
app = Flask(__name__, template_folder='templates')  # Correct

# Flask expects templates in web_app/templates/
```

**Step 3:** Restart Flask server
```bash
# Stop (Ctrl+C) and restart
python web_app/app.py
```

---

### Error: "OSError: [Errno 48] Address already in use"

**Symptoms:**
- Cannot start Flask server
- Port 5000 already in use

**Solutions:**

**Option 1: Kill existing process**
```bash
# Find process using port 5000
lsof -i :5000  # Linux/Mac

# Kill the process
kill -9 <PID>

# Or on Windows:
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

**Option 2: Use different port**
```python
# In web_app/app.py
if __name__ == "__main__":
    app.run(debug=True, port=5001)  # Use different port
```

---

### Error: "FileNotFoundError: [Errno 2] No such file or directory: 'static/styles.css'"

**Symptoms:**
- CSS not loading in web pages
- Styling missing

**Solutions:**

**Step 1:** Verify static files
```bash
ls web_app/static/
# Should show: styles.css
```

**Step 2:** Check Flask static path
```python
# Should be in web_app/static/
# Flask serves from: /static/

# In template:
<link rel="stylesheet" href="{{ url_for('static', filename='styles.css') }}">
```

---

## 8. Model Training Errors

### Error: "ValueError: Not enough samples for specified number of splits"

**Symptoms:**
- Error during train/test split
- Dataset too small

**Solutions:**

```python
# Problem: test_size=0.25 with < 4 samples
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)  # Need at least 4 samples

# Solution: Use minimum samples
min_samples = 10
if len(X) < min_samples:
    raise ValueError(f"Need at least {min_samples} samples, got {len(X)}")

# Or adjust test_size
if len(X) < 20:
    test_size = 0.1  # Use smaller test split
```

---

## 9. Logging Errors

### Error: "Failed to create logs directory"

**Symptoms:**
- Logs not being written
- No error.log file created

**Solutions:**

```bash
# Create logs directory manually
mkdir logs

# Set proper permissions
chmod 755 logs
```

---

## 10. Common Debugging Steps

### Step 1: Check Logs

```bash
# View recent errors
tail -20 logs/error.log

# Search for specific error
grep "ERROR" logs/error.log | tail -10

# Count errors by type
grep "ERROR" logs/error.log | cut -d'-' -f4 | sort | uniq -c
```

### Step 2: Enable Debug Mode

```python
# In web_app/app.py
app.run(debug=True)  # Shows detailed error pages

# In logger.py
logger.setLevel(logging.DEBUG)  # More verbose logging
```

### Step 3: Isolate the Problem

```python
# Test individual modules
python -c "from src.ml_model import load_model; print(load_model())"
python -c "from src.chatbot import load_intents; print(load_intents())"
python -c "import pandas as pd; print(pd.read_csv('data/job_dataset.csv').head())"
```

### Step 4: Review Error Stack Trace

```
File "src/ml_model.py", line 150, in train_resume_model
  results = train_resume_model(resume_path)
  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
ValueError: not enough values to unpack
```

This tells you:
- **File**: src/ml_model.py
- **Line**: 150
- **Error**: ValueError
- **Cause**: Not enough values to unpack

---

## 🎯 Quick Reference

| Error Type | Check First | Solution |
|-----------|-------------|----------|
| FileNotFoundError | File exists? Path correct? | Create file or fix path |
| PermissionError | Directory writable? | Fix permissions (chmod 755) |
| ValueError | Data type correct? | Validate input type |
| KeyError | Key exists in dict? | Add null check |
| IndexError | List has elements? | Add length check |
| NoneType Error | Null check done? | Add `if x is not None:` |
| JSONError | JSON valid? | Validate with jsonlint |
| TemplateNotFound | File in templates/? | Create template |
| Port in use | Process running? | Kill process or change port |

---

## 📞 Getting Help

1. **Check error.log** - Always the first step
2. **Google the error** - Most errors are common
3. **Check Stack Overflow** - Search the exact error message
4. **Review code** - Look at the code on the line mentioned in error
5. **Print debugging** - Add print statements to understand state
6. **Test individually** - Isolate which component fails

---

## 🔗 Useful Resources

- **Python Docs**: https://docs.python.org/3/
- **Pandas Docs**: https://pandas.pydata.org/docs/
- **Scikit-learn Docs**: https://scikit-learn.org/
- **Flask Docs**: https://flask.palletsprojects.com/
- **NLTK Docs**: https://www.nltk.org/

---

**Last Updated:** April 27, 2024
**Version:** 1.0
