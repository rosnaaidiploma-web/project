import re


def normalize_text(text: str) -> str:
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r"[^a-z0-9, ]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def split_skills(skills: str) -> list:
    skills = normalize_text(skills)
    items = [s.strip() for s in re.split(r",|;|\\n", skills) if s.strip()]
    return sorted(set(items))


def join_skills(skills: list) -> str:
    return ", ".join(sorted({skill.strip() for skill in skills if skill}))
