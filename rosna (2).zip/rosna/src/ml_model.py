"""
Machine Learning Model Module
Handles model training, prediction, and evaluation with error handling
"""

import os
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC

from .data_preprocessing import preprocess_resume_data
from .logger import get_logger, log_error, log_warning, log_info
from .exceptions import ModelError, DataValidationError

# Initialize logger
logger = get_logger()
MODULE_NAME = "MLModel"

# Model output path
MODEL_OUTPUT_PATH = os.path.join(
    os.path.dirname(__file__), os.pardir, "models", "model.pkl"
)


def build_features(df: pd.DataFrame):
    """
    Build features from resume dataset.
    
    Args:
        df: Input DataFrame with resume data
        
    Returns:
        Tuple of (X_text, X_num, y) for model training
        
    Raises:
        DataValidationError: If data validation fails
    """
    try:
        # Validate input
        if df is None:
            raise DataValidationError("DataFrame is None")

        if not isinstance(df, pd.DataFrame):
            raise DataValidationError(f"Expected DataFrame, got {type(df).__name__}")

        if df.empty:
            raise DataValidationError("DataFrame is empty")

        # Make a copy to avoid modifying original
        df = df.copy()

        # Preprocess the data
        try:
            df = preprocess_resume_data(df)
        except Exception as e:
            log_error(MODULE_NAME, e, "Error in preprocessing during feature building")
            raise DataValidationError(f"Failed to preprocess data: {str(e)}")

        # Extract text features with error handling
        try:
            feature_text = df["ResumeText"].fillna("")
            X_text = feature_text
        except Exception as e:
            log_error(MODULE_NAME, e, "Error extracting text features")
            raise DataValidationError("Failed to extract text features")

        # Extract numeric features with error handling
        try:
            X_num = df[["Experience"]].astype(float)
        except Exception as e:
            log_error(MODULE_NAME, e, "Error converting experience to numeric")
            raise DataValidationError("Failed to convert experience to numeric format")

        # Extract target variable
        try:
            if "Selected" not in df.columns:
                raise DataValidationError("'Selected' column not found in dataset")
            y = df["Selected"].astype(int)
        except Exception as e:
            log_error(MODULE_NAME, e, "Error extracting target variable")
            raise DataValidationError("Failed to extract target variable 'Selected'")

        log_info(MODULE_NAME, f"Features built successfully: {len(X_text)} samples")
        return X_text, X_num, y

    except DataValidationError as e:
        log_error(MODULE_NAME, e, "Feature building validation error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in build_features")
        raise ModelError(f"Failed to build features: {str(e)}")


def train_resume_model(
    csv_path: str, save_path: str = MODEL_OUTPUT_PATH
) -> dict:
    """
    Train multiple models and save the best performing one.
    
    Args:
        csv_path: Path to resume dataset CSV file
        save_path: Path where the trained model will be saved
        
    Returns:
        Dictionary with model path, accuracy, and evaluation metrics
        
    Raises:
        ModelError: If model training fails
        FileNotFoundError: If CSV file not found
    """
    try:
        # Validate input path
        if not isinstance(csv_path, str):
            raise DataValidationError(f"Expected string path, got {type(csv_path).__name__}")

        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"CSV file not found at: {csv_path}")

        log_info(MODULE_NAME, f"Starting model training with data from: {csv_path}")

        # Load dataset
        try:
            df = pd.read_csv(csv_path)
            log_info(MODULE_NAME, f"Loaded {len(df)} records from CSV")
        except Exception as e:
            log_error(MODULE_NAME, e, "Error reading CSV file")
            raise ModelError(f"Failed to read CSV file: {str(e)}")

        # Validate dataset
        if df.empty:
            raise DataValidationError("Dataset is empty")

        required_columns = ["Skills", "Experience", "Education", "Selected"]
        missing_cols = [col for col in required_columns if col not in df.columns]
        if missing_cols:
            raise DataValidationError(f"Missing required columns: {missing_cols}")

        # Drop rows with missing critical values
        try:
            df = df.dropna(subset=required_columns)
            log_info(MODULE_NAME, f"Dataset size after removing nulls: {len(df)} records")
        except Exception as e:
            log_error(MODULE_NAME, e, "Error handling null values")
            raise ModelError(f"Failed to handle null values: {str(e)}")

        if df.empty:
            raise DataValidationError("No valid records after removing nulls")

        # Build features
        try:
            X_text, X_num, y = build_features(df)
        except Exception as e:
            log_error(MODULE_NAME, e, "Error building features")
            raise

        # Create feature dataframe
        try:
            X = pd.DataFrame({
                "ResumeText": X_text,
                "Experience": X_num["Experience"]
            })
        except Exception as e:
            log_error(MODULE_NAME, e, "Error creating feature dataframe")
            raise ModelError(f"Failed to create feature dataframe: {str(e)}")

        # Split data into train and test sets
        try:
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.25, random_state=42
            )
            log_info(
                MODULE_NAME,
                f"Data split: {len(X_train)} training, {len(X_test)} testing"
            )
        except Exception as e:
            log_error(MODULE_NAME, e, "Error splitting dataset")
            raise ModelError(f"Failed to split dataset: {str(e)}")

        # Create preprocessor
        try:
            preprocessor = ColumnTransformer([
                ("text", TfidfVectorizer(max_features=600), "ResumeText"),
                ("num", StandardScaler(), ["Experience"]),
            ])
            log_info(MODULE_NAME, "Preprocessor created successfully")
        except Exception as e:
            log_error(MODULE_NAME, e, "Error creating preprocessor")
            raise ModelError(f"Failed to create preprocessor: {str(e)}")

        # Define and train models
        pipelines = {
            "LogisticRegression": Pipeline([
                ("preprocessor", preprocessor),
                ("clf", LogisticRegression(max_iter=500))
            ]),
            "RandomForest": Pipeline([
                ("preprocessor", preprocessor),
                ("clf", RandomForestClassifier(n_estimators=100, random_state=42))
            ]),
            "SVM": Pipeline([
                ("preprocessor", preprocessor),
                ("clf", SVC(kernel="linear", probability=True))
            ]),
        }

        best_model = None
        best_score = 0.0
        results = {}

        for model_name, pipeline in pipelines.items():
            try:
                log_info(MODULE_NAME, f"Training {model_name}...")
                pipeline.fit(X_train, y_train)

                # Make predictions
                y_pred = pipeline.predict(X_test)

                # Calculate accuracy
                accuracy = accuracy_score(y_test, y_pred)

                # Generate evaluation metrics
                cm = confusion_matrix(y_test, y_pred)
                cr = classification_report(
                    y_test, y_pred, zero_division=0, output_dict=True
                )

                results[model_name] = {
                    "accuracy": round(accuracy, 4),
                    "confusion_matrix": cm.tolist(),
                    "classification_report": cr,
                }

                log_info(
                    MODULE_NAME,
                    f"{model_name} trained with accuracy: {round(accuracy, 4)}"
                )

                # Track best model
                if accuracy > best_score:
                    best_score = accuracy
                    best_model = pipeline
                    log_info(MODULE_NAME, f"New best model: {model_name}")

            except Exception as e:
                log_error(
                    MODULE_NAME, e,
                    f"Error training {model_name}"
                )
                continue  # Continue with next model

        # Validate that at least one model was trained successfully
        if best_model is None:
            raise ModelError("All models failed to train")

        # Save best model
        try:
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            joblib.dump(best_model, save_path)
            log_info(MODULE_NAME, f"Model saved successfully to: {save_path}")
        except Exception as e:
            log_error(MODULE_NAME, e, "Error saving model")
            raise ModelError(f"Failed to save model: {str(e)}")

        return {
            "model_path": save_path,
            "best_accuracy": round(best_score, 4),
            "evaluation": results,
        }

    except (ModelError, DataValidationError, FileNotFoundError) as e:
        log_error(MODULE_NAME, e, "Model training failed")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in train_resume_model")
        raise ModelError(f"Model training failed: {str(e)}")


def load_model(model_path: str = MODEL_OUTPUT_PATH):
    """
    Load a trained model from disk.
    
    Args:
        model_path: Path to the saved model file
        
    Returns:
        Loaded model object
        
    Raises:
        FileNotFoundError: If model file doesn't exist
        ModelError: If model loading fails
    """
    try:
        # Validate path
        if not isinstance(model_path, str):
            raise ModelError(f"Expected string path, got {type(model_path).__name__}")

        if not model_path.strip():
            raise ModelError("Model path is empty")

        # Check if file exists
        if not os.path.exists(model_path):
            log_error(MODULE_NAME, FileNotFoundError(), f"Model file not found at {model_path}")
            raise FileNotFoundError(f"Model file not found at: {model_path}")

        # Load model
        try:
            model = joblib.load(model_path)
            log_info(MODULE_NAME, f"Model loaded successfully from: {model_path}")
            return model
        except Exception as e:
            log_error(MODULE_NAME, e, "Error loading model with joblib")
            raise ModelError(f"Failed to load model: {str(e)}")

    except (FileNotFoundError, ModelError) as e:
        log_error(MODULE_NAME, e, "Model loading failed")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in load_model")
        raise ModelError(f"Failed to load model: {str(e)}")


def predict_selection(
    candidate_resume_text: str,
    candidate_experience: float = 0.0,
    model=None,
    model_path: str = MODEL_OUTPUT_PATH,
) -> dict:
    """
    Predict candidate selection status using the trained model.
    
    Args:
        candidate_resume_text: Candidate's resume text
        candidate_experience: Years of experience
        model: Pre-loaded model (optional)
        model_path: Path to model file if not pre-loaded
        
    Returns:
        Dictionary with prediction (0/1) and probability
        
    Raises:
        ModelError: If prediction fails
        DataValidationError: If input validation fails
    """
    try:
        # Validate inputs
        if not isinstance(candidate_resume_text, str):
            raise DataValidationError(
                f"Resume text must be string, got {type(candidate_resume_text).__name__}"
            )

        if not candidate_resume_text.strip():
            log_warning(MODULE_NAME, "Empty resume text provided for prediction")
            raise DataValidationError("Resume text is empty")

        try:
            candidate_experience = float(candidate_experience)
        except (ValueError, TypeError) as e:
            log_error(MODULE_NAME, e, "Error converting experience to float")
            raise DataValidationError(f"Invalid experience value: {candidate_experience}")

        if candidate_experience < 0:
            log_warning(MODULE_NAME, f"Negative experience value: {candidate_experience}")
            candidate_experience = 0.0

        # Load model if not provided
        if model is None:
            try:
                model = load_model(model_path)
            except Exception as e:
                log_error(MODULE_NAME, e, "Failed to load model for prediction")
                raise ModelError(f"Cannot load model for prediction: {str(e)}")

        # Prepare input
        try:
            candidate_input = [{
                "ResumeText": candidate_resume_text,
                "Experience": candidate_experience
            }]
            candidate_df = pd.DataFrame(candidate_input)
        except Exception as e:
            log_error(MODULE_NAME, e, "Error preparing candidate input")
            raise ModelError(f"Failed to prepare input data: {str(e)}")

        # Make prediction
        try:
            prediction = model.predict(candidate_df)[0]
            prediction = int(prediction)
        except Exception as e:
            log_error(MODULE_NAME, e, "Error making prediction")
            raise ModelError(f"Failed to make prediction: {str(e)}")

        # Get prediction probability
        probability = 0.0
        try:
            if hasattr(model, "predict_proba"):
                probability_array = model.predict_proba(candidate_df)[0]
                probability = float(probability_array.max())
        except Exception as e:
            log_warning(MODULE_NAME, f"Could not calculate probability: {str(e)}")
            probability = 0.0

        result = {
            "prediction": prediction,
            "probability": round(probability * 100, 2),
        }

        log_info(
            MODULE_NAME,
            f"Prediction made: {prediction} (confidence: {round(probability * 100, 2)}%)"
        )
        return result

    except (ModelError, DataValidationError) as e:
        log_error(MODULE_NAME, e, "Prediction failed")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in predict_selection")
        raise ModelError(f"Failed to make prediction: {str(e)}")
