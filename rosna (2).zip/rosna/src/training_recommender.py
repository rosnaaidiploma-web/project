"""
Training Recommendation System Module
Recommends training courses based on missing skills
Includes comprehensive error handling
"""

from .logger import get_logger, log_error, log_warning, log_info
from .exceptions import TrainingRecommendationError

# Initialize logger
logger = get_logger()
MODULE_NAME = "TrainingRecommender"

# Mapping of skills to recommended training courses
SKILL_TRAINING_MAP = {
    "python": "Python for Data Science and Automation",
    "machine learning": "Machine Learning Fundamentals with Python",
    "deep learning": "Deep Learning with TensorFlow and Keras",
    "nlp": "Natural Language Processing with spaCy",
    "sql": "SQL for Data Analysis",
    "data analysis": "Data Analysis and Visualization",
    "tableau": "Tableau Dashboard Design",
    "power bi": "Power BI Reporting and Analytics",
    "aws": "AWS Cloud Practitioner Essentials",
    "docker": "Docker and Containerization",
    "kubernetes": "Kubernetes for Developers",
    "cybersecurity": "Cybersecurity Essentials",
    "cloud": "Cloud Computing Fundamentals",
    "analytics": "Business Analytics and Metrics",
    "leadership": "Leadership and Management Development",
    "project management": "Agile Project Management",
}


def recommend_training(missing_skills: list) -> list:
    """
    Generate training recommendations for missing skills.
    
    Args:
        missing_skills: List of missing skills
        
    Returns:
        List of recommended courses for each missing skill
        
    Raises:
        TrainingRecommendationError: If recommendation generation fails
    """
    try:
        # Validate input
        if missing_skills is None:
            raise TrainingRecommendationError("Missing skills list is None")

        if not isinstance(missing_skills, list):
            raise TrainingRecommendationError(
                f"Missing skills must be list, got {type(missing_skills).__name__}"
            )

        # Handle empty list
        if not missing_skills:
            log_info(MODULE_NAME, "No missing skills to recommend training for")
            return []

        recommendations = []

        # Generate recommendation for each missing skill
        for skill in missing_skills:
            try:
                # Validate skill entry
                if not isinstance(skill, str):
                    log_warning(
                        MODULE_NAME,
                        f"Skipping non-string skill: {type(skill).__name__}"
                    )
                    continue

                if not skill.strip():
                    log_warning(MODULE_NAME, "Skipping empty skill string")
                    continue

                # Normalize skill for lookup
                normalized_skill = skill.lower().strip()

                # Look up training course in map
                course = SKILL_TRAINING_MAP.get(normalized_skill)

                if course:
                    # Found exact match in skill map
                    recommendation = {
                        "skill": skill,
                        "course": course,
                        "source": "predefined"
                    }
                else:
                    # Generate generic recommendation
                    recommendation = {
                        "skill": skill,
                        "course": f"Advanced {skill.title()} Training",
                        "source": "generic"
                    }

                recommendations.append(recommendation)
                log_info(
                    MODULE_NAME,
                    f"Recommendation generated for skill: {skill}"
                )

            except Exception as e:
                log_warning(
                    MODULE_NAME,
                    f"Error processing skill '{skill}': {str(e)}"
                )
                # Continue with next skill instead of failing completely
                continue

        log_info(
            MODULE_NAME,
            f"Generated {len(recommendations)} training recommendations"
        )
        return recommendations

    except TrainingRecommendationError as e:
        log_error(MODULE_NAME, e, "Training recommendation validation error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in recommend_training")
        raise TrainingRecommendationError(
            f"Failed to generate training recommendations: {str(e)}"
        )
