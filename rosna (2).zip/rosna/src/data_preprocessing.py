"""
Data Preprocessing Module
Handles data cleaning, validation, and transformation with comprehensive error handling
"""

import re
import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize

from .utils import normalize_text, split_skills
from .logger import get_logger, log_error, log_warning, log_info
from .exceptions import DataValidationError, DataProcessingError

# Initialize logger
logger = get_logger()
MODULE_NAME = "DataPreprocessing"


def ensure_nltk_data():
    """
    Ensure required NLTK data is available.
    Downloads missing corpora if necessary.
    """
    try:
        stopwords.words("english")
        word_tokenize("test")
        log_info(MODULE_NAME, "NLTK data already available")
    except LookupError as e:
        try:
            log_warning(MODULE_NAME, "Downloading NLTK data...")
            nltk.download("punkt")
            nltk.download("stopwords")
            nltk.download("wordnet")
            nltk.download("averaged_perceptron_tagger")
            log_info(MODULE_NAME, "NLTK data downloaded successfully")
        except Exception as download_error:
            log_error(MODULE_NAME, download_error, "Failed to download NLTK data")
            raise DataProcessingError(
                "Failed to initialize NLTK resources. Please check your internet connection."
            )


# Initialize NLTK data
try:
    ensure_nltk_data()
    STOP_WORDS = set(stopwords.words("english"))
    LEMMATIZER = WordNetLemmatizer()
except Exception as e:
    log_error(MODULE_NAME, e, "Failed to initialize preprocessing components")
    raise


def clean_text(text: str) -> str:
    """
    Clean and preprocess text.
    - Converts to lowercase
    - Removes special characters
    - Tokenizes text
    - Removes stopwords
    - Lemmatizes tokens
    
    Args:
        text: Input text to clean
        
    Returns:
        Cleaned text string
    """
    try:
        # Handle non-string inputs gracefully
        if not isinstance(text, str):
            log_warning(MODULE_NAME, f"clean_text received non-string input: {type(text)}")
            return ""

        # Convert to lowercase
        text = text.lower()

        # Remove special characters (keep only alphanumeric and spaces)
        text = re.sub(r"[^a-z0-9 ]", " ", text)

        # Tokenize text
        tokens = word_tokenize(text)

        # Remove stopwords and short tokens
        tokens = [
            token for token in tokens if token not in STOP_WORDS and len(token) > 1
        ]

        # Lemmatize tokens
        lemmas = [LEMMATIZER.lemmatize(token) for token in tokens]

        result = " ".join(lemmas)
        return result

    except Exception as e:
        log_error(MODULE_NAME, e, "Error in clean_text function")
        return ""  # Return empty string on error to prevent pipeline failure


def preprocess_skills(skills: str) -> str:
    """
    Preprocess skills string.
    Splits and normalizes skills.
    
    Args:
        skills: Skills string (comma or semicolon separated)
        
    Returns:
        Normalized skills string
    """
    try:
        if not isinstance(skills, str) or not skills.strip():
            return ""

        items = split_skills(skills)
        return ", ".join(items)

    except Exception as e:
        log_error(MODULE_NAME, e, "Error preprocessing skills")
        return str(skills)  # Return original if processing fails


def preprocess_resume_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Preprocess resume dataset.
    - Validates input DataFrame
    - Removes duplicates
    - Handles missing values
    - Cleans text fields
    - Converts numeric fields
    
    Args:
        df: Input DataFrame with resume data
        
    Returns:
        Preprocessed DataFrame
        
    Raises:
        DataValidationError: If input validation fails
        DataProcessingError: If preprocessing fails
    """
    try:
        # Validate input
        if df is None:
            raise DataValidationError("Input DataFrame is None")

        if not isinstance(df, pd.DataFrame):
            raise DataValidationError(
                f"Expected DataFrame, got {type(df).__name__}"
            )

        if df.empty:
            log_warning(MODULE_NAME, "preprocess_resume_data received empty DataFrame")
            return df

        log_info(MODULE_NAME, f"Preprocessing {len(df)} resume records")

        # Make a copy to avoid modifying original
        df = df.copy()

        # Remove duplicates
        initial_rows = len(df)
        df = df.drop_duplicates().reset_index(drop=True)
        removed_duplicates = initial_rows - len(df)
        if removed_duplicates > 0:
            log_info(MODULE_NAME, f"Removed {removed_duplicates} duplicate records")

        # Handle missing values
        df = df.fillna("")

        # Validate required columns
        required_columns = ["Skills", "Education", "Experience"]
        missing_cols = [col for col in required_columns if col not in df.columns]
        if missing_cols:
            log_warning(
                MODULE_NAME, f"Resume data missing columns: {missing_cols}"
            )

        # Process Skills column
        if "Skills" in df.columns:
            try:
                df["Skills"] = df["Skills"].apply(preprocess_skills)
            except Exception as e:
                log_error(MODULE_NAME, e, "Error processing Skills column")
                df["Skills"] = ""

        # Process Education column - clean text
        if "Education" in df.columns:
            try:
                df["EducationText"] = df["Education"].apply(clean_text)
            except Exception as e:
                log_error(MODULE_NAME, e, "Error processing Education column")
                df["EducationText"] = ""

        # Process Experience column - convert to numeric
        if "Experience" in df.columns:
            try:
                df["Experience"] = (
                    pd.to_numeric(df["Experience"], errors="coerce")
                    .fillna(0)
                    .astype(int)
                )
            except Exception as e:
                log_error(MODULE_NAME, e, "Error processing Experience column")
                df["Experience"] = 0

        # Create combined ResumeText field
        try:
            df["ResumeText"] = df.apply(
                lambda row: " ".join(
                    [str(row.get("Skills", "")), str(row.get("EducationText", ""))]
                ).strip(),
                axis=1,
            )
        except Exception as e:
            log_error(MODULE_NAME, e, "Error creating ResumeText field")
            df["ResumeText"] = ""

        log_info(MODULE_NAME, "Resume preprocessing completed successfully")
        return df

    except DataValidationError as e:
        log_error(MODULE_NAME, e, "Resume data validation failed")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in preprocess_resume_data")
        raise DataProcessingError(
            f"Failed to preprocess resume data: {str(e)}"
        )


def preprocess_job_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Preprocess job dataset.
    - Validates input DataFrame
    - Processes required skills
    - Cleans job descriptions
    
    Args:
        df: Input DataFrame with job data
        
    Returns:
        Preprocessed DataFrame
        
    Raises:
        DataValidationError: If input validation fails
        DataProcessingError: If preprocessing fails
    """
    try:
        # Validate input
        if df is None:
            raise DataValidationError("Input DataFrame is None")

        if not isinstance(df, pd.DataFrame):
            raise DataValidationError(f"Expected DataFrame, got {type(df).__name__}")

        if df.empty:
            log_warning(MODULE_NAME, "preprocess_job_data received empty DataFrame")
            return df

        log_info(MODULE_NAME, f"Preprocessing {len(df)} job records")

        df = df.copy()

        # Remove duplicates
        initial_rows = len(df)
        df = df.drop_duplicates().reset_index(drop=True)
        removed_duplicates = initial_rows - len(df)
        if removed_duplicates > 0:
            log_info(MODULE_NAME, f"Removed {removed_duplicates} duplicate job records")

        # Handle missing values
        df = df.fillna("")

        # Process RequiredSkills
        if "RequiredSkills" in df.columns:
            try:
                df["RequiredSkills"] = df["RequiredSkills"].apply(preprocess_skills)
            except Exception as e:
                log_error(MODULE_NAME, e, "Error processing RequiredSkills column")
                df["RequiredSkills"] = ""

        # Process Description - clean text
        if "Description" in df.columns:
            try:
                df["DescriptionText"] = df["Description"].apply(clean_text)
            except Exception as e:
                log_error(MODULE_NAME, e, "Error processing Description column")
                df["DescriptionText"] = ""

        # Create combined JobText field
        try:
            df["JobText"] = df.apply(
                lambda row: " ".join(
                    [
                        str(row.get("RequiredSkills", "")),
                        str(row.get("DescriptionText", "")),
                    ]
                ).strip(),
                axis=1,
            )
        except Exception as e:
            log_error(MODULE_NAME, e, "Error creating JobText field")
            df["JobText"] = ""

        log_info(MODULE_NAME, "Job preprocessing completed successfully")
        return df

    except DataValidationError as e:
        log_error(MODULE_NAME, e, "Job data validation failed")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in preprocess_job_data")
        raise DataProcessingError(
            f"Failed to preprocess job data: {str(e)}"
        )


def preprocess_employee_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Preprocess employee dataset.
    - Validates input DataFrame
    - Processes skills
    - Converts experience to numeric
    
    Args:
        df: Input DataFrame with employee data
        
    Returns:
        Preprocessed DataFrame
        
    Raises:
        DataValidationError: If input validation fails
        DataProcessingError: If preprocessing fails
    """
    try:
        # Validate input
        if df is None:
            raise DataValidationError("Input DataFrame is None")

        if not isinstance(df, pd.DataFrame):
            raise DataValidationError(f"Expected DataFrame, got {type(df).__name__}")

        if df.empty:
            log_warning(MODULE_NAME, "preprocess_employee_data received empty DataFrame")
            return df

        log_info(MODULE_NAME, f"Preprocessing {len(df)} employee records")

        df = df.copy()

        # Remove duplicates
        initial_rows = len(df)
        df = df.drop_duplicates().reset_index(drop=True)
        removed_duplicates = initial_rows - len(df)
        if removed_duplicates > 0:
            log_info(MODULE_NAME, f"Removed {removed_duplicates} duplicate employee records")

        # Handle missing values
        df = df.fillna("")

        # Process Skills column
        if "Skills" in df.columns:
            try:
                df["Skills"] = df["Skills"].apply(preprocess_skills)
            except Exception as e:
                log_error(MODULE_NAME, e, "Error processing employee Skills column")
                df["Skills"] = ""

        # Process YearsExperience - convert to numeric
        if "YearsExperience" in df.columns:
            try:
                df["YearsExperience"] = (
                    pd.to_numeric(df["YearsExperience"], errors="coerce")
                    .fillna(0)
                    .astype(int)
                )
            except Exception as e:
                log_error(MODULE_NAME, e, "Error processing YearsExperience column")
                df["YearsExperience"] = 0

        log_info(MODULE_NAME, "Employee preprocessing completed successfully")
        return df

    except DataValidationError as e:
        log_error(MODULE_NAME, e, "Employee data validation failed")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in preprocess_employee_data")
        raise DataProcessingError(
            f"Failed to preprocess employee data: {str(e)}"
        )
