"""
Promotion Analysis Module
Analyzes employee readiness for promotions and higher roles
Includes comprehensive error handling
"""

from .utils import split_skills
from .logger import get_logger, log_error, log_warning, log_info
from .exceptions import PromotionAnalysisError

# Initialize logger
logger = get_logger()
MODULE_NAME = "PromotionAnalysis"


def analyze_promotion_readiness(employee_skills: str, target_role_skills: str) -> dict:
    """
    Analyze employee readiness for a target role based on skill comparison.
    
    Args:
        employee_skills: Employee's current skills
        target_role_skills: Target role's required skills
        
    Returns:
        Dictionary with skill analysis and readiness score
        
    Raises:
        PromotionAnalysisError: If analysis fails
    """
    try:
        # Validate inputs
        if not isinstance(employee_skills, str) or not isinstance(target_role_skills, str):
            raise PromotionAnalysisError("Skills must be strings")

        # Parse skills safely with error handling
        try:
            employee_set = {
                skill.lower().strip()
                for skill in split_skills(employee_skills)
                if skill.strip()
            }
        except Exception as e:
            log_warning(MODULE_NAME, f"Error parsing employee skills: {str(e)}")
            employee_set = set()

        try:
            target_set = {
                skill.lower().strip()
                for skill in split_skills(target_role_skills)
                if skill.strip()
            }
        except Exception as e:
            log_warning(MODULE_NAME, f"Error parsing target role skills: {str(e)}")
            target_set = set()

        # Find missing skills
        missing = sorted(target_set - employee_set)

        # Calculate readiness score
        readiness_score = 0.0
        if target_set:
            try:
                matched_skills = len(target_set) - len(missing)
                readiness_score = round(
                    (matched_skills / len(target_set)) * 100, 2
                )
            except Exception as e:
                log_warning(MODULE_NAME, f"Error calculating readiness score: {str(e)}")
                readiness_score = 0.0

        result = {
            "employee_skills": sorted(employee_set),
            "target_skills": sorted(target_set),
            "missing_skills": missing,
            "readiness_score": readiness_score,
        }

        log_info(
            MODULE_NAME,
            f"Promotion readiness analyzed: {readiness_score}% ready"
        )
        return result

    except PromotionAnalysisError as e:
        log_error(MODULE_NAME, e, "Promotion readiness analysis error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in analyze_promotion_readiness")
        raise PromotionAnalysisError(f"Failed to analyze promotion readiness: {str(e)}")


def compare_employee_to_role(employee_record: dict, role_record: dict) -> dict:
    """
    Compare employee capabilities with target role requirements.
    
    Args:
        employee_record: Employee data dictionary
        role_record: Role data dictionary
        
    Returns:
        Dictionary with comparison results and readiness score
        
    Raises:
        PromotionAnalysisError: If comparison fails
    """
    try:
        # Validate inputs
        if not isinstance(employee_record, dict):
            raise PromotionAnalysisError(
                f"Employee record must be dict, got {type(employee_record).__name__}"
            )

        if not isinstance(role_record, dict):
            raise PromotionAnalysisError(
                f"Role record must be dict, got {type(role_record).__name__}"
            )

        if not employee_record:
            log_warning(MODULE_NAME, "Received empty employee record")
            raise PromotionAnalysisError("Employee record is empty")

        if not role_record:
            log_warning(MODULE_NAME, "Received empty role record")
            raise PromotionAnalysisError("Role record is empty")

        # Extract values safely with defaults
        try:
            employee_name = employee_record.get("Name", "Employee")
            if not isinstance(employee_name, str):
                employee_name = str(employee_name)
        except Exception as e:
            log_warning(MODULE_NAME, f"Error extracting employee name: {str(e)}")
            employee_name = "Employee"

        try:
            current_role = employee_record.get("CurrentRole", "Unknown")
            if not isinstance(current_role, str):
                current_role = str(current_role)
        except Exception as e:
            log_warning(MODULE_NAME, f"Error extracting current role: {str(e)}")
            current_role = "Unknown"

        try:
            target_role = role_record.get("Role", "Target Role")
            if not isinstance(target_role, str):
                target_role = str(target_role)
        except Exception as e:
            log_warning(MODULE_NAME, f"Error extracting target role: {str(e)}")
            target_role = "Target Role"

        # Get skills safely
        employee_skills = employee_record.get("Skills", "")
        role_skills = role_record.get("RequiredSkills", "")

        if not isinstance(employee_skills, str):
            employee_skills = str(employee_skills)
        if not isinstance(role_skills, str):
            role_skills = str(role_skills)

        # Analyze promotion readiness
        try:
            analysis = analyze_promotion_readiness(employee_skills, role_skills)
        except Exception as e:
            log_error(MODULE_NAME, e, "Error in promotion readiness analysis")
            analysis = {
                "employee_skills": [],
                "target_skills": [],
                "missing_skills": [],
                "readiness_score": 0.0,
            }

        result = {
            "employee": employee_name,
            "current_role": current_role,
            "target_role": target_role,
            "readiness_score": analysis["readiness_score"],
            "missing_skills": analysis["missing_skills"],
        }

        log_info(
            MODULE_NAME,
            f"Comparison complete: {employee_name} readiness for {target_role} is {analysis['readiness_score']}%"
        )
        return result

    except PromotionAnalysisError as e:
        log_error(MODULE_NAME, e, "Employee-role comparison error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in compare_employee_to_role")
        raise PromotionAnalysisError(f"Failed to compare employee to role: {str(e)}")
