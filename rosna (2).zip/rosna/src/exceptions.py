"""
Custom Exceptions for HRM System
Provides specific exception types for different error scenarios
"""


class HRMException(Exception):
    """Base exception class for all HRM system errors"""

    pass


class DataValidationError(HRMException):
    """Raised when data validation fails"""

    pass


class FileHandlingError(HRMException):
    """Raised when file operations fail"""

    pass


class ResumeAnalysisError(HRMException):
    """Raised when resume analysis fails"""

    pass


class ModelError(HRMException):
    """Raised when model operations fail (loading, prediction)"""

    pass


class SkillGapError(HRMException):
    """Raised when skill gap analysis fails"""

    pass


class PromotionAnalysisError(HRMException):
    """Raised when promotion analysis fails"""

    pass


class TrainingRecommendationError(HRMException):
    """Raised when training recommendation fails"""

    pass


class ChatbotError(HRMException):
    """Raised when chatbot operations fail"""

    pass


class PDFReportError(HRMException):
    """Raised when PDF report generation fails"""

    pass


class ConfigurationError(HRMException):
    """Raised when system configuration is invalid"""

    pass


class DataProcessingError(HRMException):
    """Raised when data preprocessing fails"""

    pass
