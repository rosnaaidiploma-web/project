"""
Centralized Logging Configuration for HRM System
Provides consistent error logging across all modules
"""

import logging
import os
from datetime import datetime
from pathlib import Path


class HRMLogger:
    """
    Centralized logging configuration for the HRM system.
    Handles file and console logging with proper formatting.
    """

    _instance = None
    _logger = None

    def __new__(cls):
        """Ensure singleton pattern for logger"""
        if cls._instance is None:
            cls._instance = super(HRMLogger, cls).__new__(cls)
            cls._instance._initialize_logger()
        return cls._instance

    def _initialize_logger(self):
        """Initialize logger with file and console handlers"""
        # Create logs directory if it doesn't exist
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)

        # Set up logger
        self._logger = logging.getLogger("HRM_System")
        self._logger.setLevel(logging.DEBUG)

        # Avoid duplicate handlers
        if self._logger.handlers:
            return

        # Create formatters
        detailed_formatter = logging.Formatter(
            fmt="%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(funcName)s() - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

        console_formatter = logging.Formatter(
            fmt="%(levelname)s - %(message)s"
        )

        # File handler (logs everything)
        error_log_path = log_dir / "error.log"
        file_handler = logging.FileHandler(error_log_path, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(detailed_formatter)
        self._logger.addHandler(file_handler)

        # Console handler (logs warnings and above)
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        console_handler.setFormatter(console_formatter)
        self._logger.addHandler(console_handler)

    def get_logger(self):
        """Return the configured logger instance"""
        return self._logger


# Function to get logger instance
def get_logger():
    """
    Get the singleton logger instance.
    Usage: logger = get_logger()
    """
    return HRMLogger().get_logger()


# Helper functions for common logging patterns
def log_error(module_name: str, error: Exception, context: str = ""):
    """
    Log an error with context information
    Args:
        module_name: Name of the module where error occurred
        error: The exception object
        context: Additional context about the error
    """
    logger = get_logger()
    logger.error(
        f"[{module_name}] {context} | Error: {type(error).__name__}: {str(error)}"
    )


def log_warning(module_name: str, message: str):
    """Log a warning message with module context"""
    logger = get_logger()
    logger.warning(f"[{module_name}] {message}")


def log_info(module_name: str, message: str):
    """Log an info message with module context"""
    logger = get_logger()
    logger.info(f"[{module_name}] {message}")


def log_debug(module_name: str, message: str):
    """Log a debug message with module context"""
    logger = get_logger()
    logger.debug(f"[{module_name}] {message}")
