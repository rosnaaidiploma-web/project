"""
Skill Gap Analysis Module
Detects and reports skill gaps between candidates and job requirements
Includes comprehensive error handling
"""

from .utils import split_skills
from .logger import get_logger, log_error, log_warning, log_info
from .exceptions import SkillGapError

# Initialize logger
logger = get_logger()
MODULE_NAME = "SkillGap"


def detect_skill_gap(candidate_skills: str, required_skills: str) -> dict:
    """
    Detect skill gaps between candidate and required skills.
    
    Args:
        candidate_skills: Candidate's skills (comma-separated)
        required_skills: Job's required skills (comma-separated)
        
    Returns:
        Dictionary with skill analysis including missing skills and gap percentage
        
    Raises:
        SkillGapError: If skill gap detection fails
    """
    try:
        # Validate inputs
        if not isinstance(candidate_skills, str) or not isinstance(required_skills, str):
            raise SkillGapError("Skills must be strings")

        # Parse skills safely with error handling
        try:
            candidate_set = {
                skill.lower().strip()
                for skill in split_skills(candidate_skills)
                if skill.strip()
            }
        except Exception as e:
            log_warning(MODULE_NAME, f"Error parsing candidate skills: {str(e)}")
            candidate_set = set()

        try:
            required_set = {
                skill.lower().strip()
                for skill in split_skills(required_skills)
                if skill.strip()
            }
        except Exception as e:
            log_warning(MODULE_NAME, f"Error parsing required skills: {str(e)}")
            required_set = set()

        # Find missing skills
        missing = sorted(required_set - candidate_set)

        # Calculate gap percentage
        gap_percentage = 0.0
        if required_set:
            try:
                gap_percentage = round(len(missing) / len(required_set) * 100, 2)
            except Exception as e:
                log_warning(MODULE_NAME, f"Error calculating gap percentage: {str(e)}")
                gap_percentage = 0.0

        result = {
            "candidate_skills": sorted(candidate_set),
            "required_skills": sorted(required_set),
            "missing_skills": missing,
            "gap_percentage": gap_percentage,
        }

        log_info(
            MODULE_NAME,
            f"Skill gap detected: {gap_percentage}% ({len(missing)} missing skills)"
        )
        return result

    except SkillGapError as e:
        log_error(MODULE_NAME, e, "Skill gap detection validation error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in detect_skill_gap")
        raise SkillGapError(f"Failed to detect skill gap: {str(e)}")


def generate_gap_report(
    candidate_name: str, candidate_skills: str, required_skills: str, role: str
) -> dict:
    """
    Generate a skill gap report for a candidate and role.
    
    Args:
        candidate_name: Name of the candidate
        candidate_skills: Candidate's skills
        required_skills: Role's required skills
        role: Target role name
        
    Returns:
        Dictionary with gap report including name, role, missing skills, and summary
        
    Raises:
        SkillGapError: If report generation fails
    """
    try:
        # Validate inputs
        if not isinstance(candidate_name, str) or not candidate_name.strip():
            raise SkillGapError("Candidate name must be non-empty string")

        if not isinstance(role, str) or not role.strip():
            raise SkillGapError("Role must be non-empty string")

        if not isinstance(candidate_skills, str) or not isinstance(required_skills, str):
            raise SkillGapError("Skills must be strings")

        # Detect skill gaps with error handling
        try:
            gap = detect_skill_gap(candidate_skills, required_skills)
        except Exception as e:
            log_error(MODULE_NAME, e, "Error detecting skill gaps for report")
            raise SkillGapError(f"Failed to detect gaps: {str(e)}")

        # Generate summary safely
        try:
            missing_count = len(gap["missing_skills"])
            summary = (
                f"Candidate {candidate_name} is missing {missing_count} skills "
                f"for role {role}. Skill gap: {gap['gap_percentage']}%"
            )
        except Exception as e:
            log_warning(MODULE_NAME, f"Error generating summary: {str(e)}")
            summary = f"Skill gap report for {candidate_name}"

        result = {
            "Name": candidate_name,
            "Role": role,
            "MissingSkills": gap["missing_skills"],
            "GapPercentage": gap["gap_percentage"],
            "Summary": summary,
        }

        log_info(
            MODULE_NAME,
            f"Gap report generated for {candidate_name} for role {role}"
        )
        return result

    except SkillGapError as e:
        log_error(MODULE_NAME, e, "Gap report generation error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in generate_gap_report")
        raise SkillGapError(f"Failed to generate gap report: {str(e)}")
