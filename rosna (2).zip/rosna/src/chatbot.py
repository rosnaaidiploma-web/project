"""
AI Chatbot Module
Handles intent classification and response generation
Includes comprehensive error handling
"""

import json
import os
import re
from nltk.tokenize import word_tokenize

from .utils import normalize_text
from .logger import get_logger, log_error, log_warning, log_info
from .exceptions import ChatbotError

# Initialize logger
logger = get_logger()
MODULE_NAME = "Chatbot"

# Path to intents file
INTENTS_PATH = os.path.join(
    os.path.dirname(__file__), os.pardir, "chatbot", "intents.json"
)

# Default fallback response
DEFAULT_RESPONSE = (
    "I'm here to help with HR-related questions. "
    "You can ask me about jobs, resumes, promotions, or training. "
    "What would you like to know?"
)


def load_intents() -> list:
    """
    Load intents from JSON file.
    
    Returns:
        List of intents with patterns and responses
        
    Raises:
        ChatbotError: If intent loading fails
    """
    try:
        # Validate intents file path
        if not os.path.exists(INTENTS_PATH):
            log_error(
                MODULE_NAME,
                FileNotFoundError(),
                f"Intents file not found at {INTENTS_PATH}"
            )
            raise FileNotFoundError(f"Intents file not found: {INTENTS_PATH}")

        # Load JSON file
        try:
            with open(INTENTS_PATH, "r", encoding="utf-8") as file:
                data = json.load(file)
        except json.JSONDecodeError as e:
            log_error(MODULE_NAME, e, "Invalid JSON format in intents file")
            raise ChatbotError(f"Invalid JSON in intents file: {str(e)}")
        except IOError as e:
            log_error(MODULE_NAME, e, "Error reading intents file")
            raise ChatbotError(f"Cannot read intents file: {str(e)}")

        # Extract intents list
        intents = data.get("intents", [])

        if not isinstance(intents, list):
            log_warning(MODULE_NAME, "Intents is not a list")
            return []

        log_info(MODULE_NAME, f"Loaded {len(intents)} intents successfully")
        return intents

    except ChatbotError as e:
        log_error(MODULE_NAME, e, "Intent loading error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in load_intents")
        raise ChatbotError(f"Failed to load intents: {str(e)}")


def classify_intent(user_message: str) -> dict:
    """
    Classify user message into an intent category.
    
    Args:
        user_message: Raw user input message
        
    Returns:
        Dictionary with classified intent tag and responses
        
    Raises:
        ChatbotError: If classification fails
    """
    try:
        # Validate input
        if user_message is None:
            raise ChatbotError("User message is None")

        if not isinstance(user_message, str):
            raise ChatbotError(
                f"User message must be string, got {type(user_message).__name__}"
            )

        if not user_message.strip():
            log_warning(MODULE_NAME, "Received empty user message")
            return {
                "tag": "unknown",
                "match_count": 0,
                "responses": [DEFAULT_RESPONSE]
            }

        # Normalize message
        try:
            normalized_message = normalize_text(user_message)
        except Exception as e:
            log_warning(MODULE_NAME, f"Error normalizing message: {str(e)}")
            normalized_message = user_message.lower()

        # Tokenize message
        try:
            tokens = word_tokenize(normalized_message)
        except Exception as e:
            log_warning(MODULE_NAME, f"Error tokenizing message: {str(e)}")
            tokens = normalized_message.split()

        # Load intents safely
        try:
            intents = load_intents()
        except Exception as e:
            log_error(MODULE_NAME, e, "Failed to load intents for classification")
            return {
                "tag": "unknown",
                "match_count": 0,
                "responses": [DEFAULT_RESPONSE]
            }

        if not intents:
            log_warning(MODULE_NAME, "No intents available for classification")
            return {
                "tag": "unknown",
                "match_count": 0,
                "responses": [DEFAULT_RESPONSE]
            }

        # Find best matching intent
        best = {
            "tag": "unknown",
            "match_count": 0,
            "responses": [DEFAULT_RESPONSE]
        }

        try:
            for intent in intents:
                try:
                    # Get patterns safely
                    patterns = intent.get("patterns", [])
                    if not isinstance(patterns, list):
                        log_warning(
                            MODULE_NAME,
                            f"Patterns in intent {intent.get('tag')} is not a list"
                        )
                        continue

                    # Count pattern matches
                    match_count = sum(
                        1 for pattern in patterns
                        if isinstance(pattern, str) and pattern in normalized_message
                    )

                    # Update best match
                    if match_count > best["match_count"]:
                        responses = intent.get("responses", [DEFAULT_RESPONSE])
                        if not isinstance(responses, list):
                            responses = [DEFAULT_RESPONSE]
                        best = {
                            "tag": intent.get("tag", "unknown"),
                            "match_count": match_count,
                            "responses": responses if responses else [DEFAULT_RESPONSE]
                        }

                except Exception as e:
                    log_warning(MODULE_NAME, f"Error processing intent: {str(e)}")
                    continue

        except Exception as e:
            log_error(MODULE_NAME, e, "Error iterating through intents")
            return best

        # If no exact match, use keyword-based fallback
        if best["match_count"] == 0:
            try:
                keyword_map = {
                    "job_query": ["job", "opening", "role", "position"],
                    "resume_help": ["resume", "cv", "application", "profile"],
                    "promotion": ["promotion", "ready", "growth", "advance"],
                    "training": ["learn", "train", "skill", "course", "develop"],
                }

                # Check for keyword matches
                for tag, keywords in keyword_map.items():
                    if any(keyword in tokens for keyword in keywords):
                        # Find matching intent
                        for intent in intents:
                            if intent.get("tag") == tag:
                                responses = intent.get("responses", [DEFAULT_RESPONSE])
                                if not isinstance(responses, list):
                                    responses = [DEFAULT_RESPONSE]
                                return {
                                    "tag": tag,
                                    "responses": responses if responses else [DEFAULT_RESPONSE]
                                }
                        break

            except Exception as e:
                log_warning(MODULE_NAME, f"Error in keyword fallback: {str(e)}")

        log_info(
            MODULE_NAME,
            f"Intent classified: {best['tag']} (confidence: {best['match_count']})"
        )
        return best

    except ChatbotError as e:
        log_error(MODULE_NAME, e, "Intent classification error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in classify_intent")
        raise ChatbotError(f"Failed to classify intent: {str(e)}")


def get_chatbot_response(user_message: str) -> str:
    """
    Get chatbot response for user message.
    
    Args:
        user_message: User input message
        
    Returns:
        Chatbot response string
        
    Raises:
        ChatbotError: If response generation fails
    """
    try:
        # Validate input
        if user_message is None:
            raise ChatbotError("User message is None")

        if not isinstance(user_message, str):
            raise ChatbotError(
                f"User message must be string, got {type(user_message).__name__}"
            )

        # Classify intent
        try:
            intent = classify_intent(user_message)
        except Exception as e:
            log_error(MODULE_NAME, e, "Failed to classify intent for response")
            return DEFAULT_RESPONSE

        # Get responses
        responses = intent.get("responses", [DEFAULT_RESPONSE])

        if not responses:
            log_warning(MODULE_NAME, "No responses available for intent")
            return DEFAULT_RESPONSE

        # Select first response safely
        try:
            response = responses[0] if isinstance(responses, list) else DEFAULT_RESPONSE
            if not isinstance(response, str):
                response = DEFAULT_RESPONSE
        except Exception as e:
            log_warning(MODULE_NAME, f"Error extracting response: {str(e)}")
            response = DEFAULT_RESPONSE

        log_info(MODULE_NAME, f"Response generated: {response[:50]}...")
        return response

    except ChatbotError as e:
        log_error(MODULE_NAME, e, "Response generation error")
        return DEFAULT_RESPONSE
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in get_chatbot_response")
        return DEFAULT_RESPONSE
