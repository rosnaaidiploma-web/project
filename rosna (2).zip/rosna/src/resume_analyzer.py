"""
Resume Analyzer Module
Extracts resume information and analyzes candidate fit against job requirements
Includes comprehensive error handling
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .data_preprocessing import clean_text, preprocess_skills
from .utils import split_skills
from .logger import get_logger, log_error, log_warning, log_info
from .exceptions import ResumeAnalysisError

# Initialize logger
logger = get_logger()
MODULE_NAME = "ResumeAnalyzer"


def extract_resume_fields(resume_text: str) -> dict:
    """
    Extract key fields from resume text.
    
    Args:
        resume_text: Raw resume text content
        
    Returns:
        Dictionary containing extracted Name, Skills, and cleaned ResumeText
        
    Raises:
        ResumeAnalysisError: If resume text is invalid or extraction fails
    """
    try:
        # Validate input
        if resume_text is None:
            raise ResumeAnalysisError("Resume text is None")

        if not isinstance(resume_text, str):
            raise ResumeAnalysisError(
                f"Expected string resume text, got {type(resume_text).__name__}"
            )

        if not resume_text.strip():
            log_warning(MODULE_NAME, "Received empty resume text")
            raise ResumeAnalysisError("Resume text is empty")

        # Extract lines from resume
        try:
            lines = [line.strip() for line in resume_text.splitlines() if line.strip()]
        except Exception as e:
            log_error(MODULE_NAME, e, "Error splitting resume into lines")
            raise ResumeAnalysisError("Failed to parse resume text")

        if not lines:
            log_warning(MODULE_NAME, "No valid lines found in resume")
            raise ResumeAnalysisError("Resume contains no readable content")

        # Extract name (first line)
        name = lines[0] if lines else "Candidate"

        # Combine all text
        full_text = " ".join(lines)

        # Clean the entire resume text
        try:
            cleaned_text = clean_text(full_text)
        except Exception as e:
            log_error(MODULE_NAME, e, "Error cleaning resume text")
            cleaned_text = ""

        # Extract skills section
        skills = []
        try:
            if "skills:" in full_text.lower():
                # Extract skills section
                candidate_skills = (
                    full_text.lower().split("skills:")[-1].split("experience:")[0]
                )
                skills = split_skills(candidate_skills)
        except Exception as e:
            log_warning(MODULE_NAME, f"Could not extract skills section: {str(e)}")
            skills = []

        result = {
            "Name": name,
            "Skills": ", ".join(skills) if skills else "",
            "ResumeText": cleaned_text,
        }

        log_info(MODULE_NAME, f"Successfully extracted resume for: {name}")
        return result

    except ResumeAnalysisError as e:
        log_error(MODULE_NAME, e, "Resume analysis validation error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in extract_resume_fields")
        raise ResumeAnalysisError(f"Failed to extract resume fields: {str(e)}")


def compute_match_score(resume_text: str, job_text: str) -> float:
    """
    Compute TF-IDF based similarity score between resume and job description.
    
    Args:
        resume_text: Cleaned resume text
        job_text: Cleaned job description text
        
    Returns:
        Similarity score as percentage (0-100)
        
    Raises:
        ResumeAnalysisError: If score computation fails
    """
    try:
        # Validate inputs
        if not isinstance(resume_text, str) or not isinstance(job_text, str):
            raise ResumeAnalysisError("Resume and job text must be strings")

        if not resume_text.strip() or not job_text.strip():
            log_warning(
                MODULE_NAME,
                "Empty text provided for match score computation"
            )
            return 0.0

        try:
            # Clean texts if not already cleaned
            texts = [clean_text(resume_text), clean_text(job_text)]

            # Create TF-IDF vectorizer with safety limits
            vectorizer = TfidfVectorizer(max_features=500)

            # Fit and transform texts
            tfidf_matrix = vectorizer.fit_transform(texts)

            # Compute cosine similarity
            similarity_matrix = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])

            # Extract similarity value
            if similarity_matrix is None or len(similarity_matrix) == 0:
                log_warning(MODULE_NAME, "Similarity matrix is empty")
                return 0.0

            similarity = similarity_matrix[0][0]

            # Convert to percentage
            match_score = round(float(similarity) * 100, 2)

            # Ensure score is in valid range
            match_score = max(0.0, min(100.0, match_score))

            log_info(
                MODULE_NAME,
                f"Computed match score: {match_score}%"
            )
            return match_score

        except Exception as e:
            log_error(MODULE_NAME, e, "Error in TF-IDF vectorization")
            raise ResumeAnalysisError(
                f"Failed to compute similarity score: {str(e)}"
            )

    except ResumeAnalysisError as e:
        log_error(MODULE_NAME, e, "Resume analysis error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in compute_match_score")
        raise ResumeAnalysisError(f"Failed to compute match score: {str(e)}")


def match_skills(candidate_skills: str, required_skills: str) -> dict:
    """
    Match candidate skills against required skills.
    
    Args:
        candidate_skills: Candidate's skills (comma-separated)
        required_skills: Job's required skills (comma-separated)
        
    Returns:
        Dictionary with matched skills, missing skills, and match percentage
        
    Raises:
        ResumeAnalysisError: If skill matching fails
    """
    try:
        # Validate inputs
        if not isinstance(candidate_skills, str) or not isinstance(required_skills, str):
            raise ResumeAnalysisError("Skills must be strings")

        # Parse skills safely
        try:
            candidate_set = {
                skill.strip().lower()
                for skill in split_skills(candidate_skills)
                if skill.strip()
            }
        except Exception as e:
            log_warning(MODULE_NAME, f"Error parsing candidate skills: {str(e)}")
            candidate_set = set()

        try:
            required_set = {
                skill.strip().lower()
                for skill in split_skills(required_skills)
                if skill.strip()
            }
        except Exception as e:
            log_warning(MODULE_NAME, f"Error parsing required skills: {str(e)}")
            required_set = set()

        # Find matches and missing skills
        matched = sorted(candidate_set & required_set)
        missing = sorted(required_set - candidate_set)

        # Calculate match percentage
        match_percent = 0.0
        if required_set:
            try:
                match_percent = round(len(matched) / len(required_set) * 100, 2)
            except Exception as e:
                log_warning(MODULE_NAME, f"Error calculating match percentage: {str(e)}")
                match_percent = 0.0

        result = {
            "matched_skills": matched,
            "missing_skills": missing,
            "match_percent": match_percent,
        }

        log_info(
            MODULE_NAME,
            f"Skill match computed: {match_percent}% ({len(matched)} of {len(required_set)} skills)"
        )
        return result

    except ResumeAnalysisError as e:
        log_error(MODULE_NAME, e, "Skill matching error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in match_skills")
        raise ResumeAnalysisError(f"Failed to match skills: {str(e)}")


def analyze_against_job(candidate: dict, job: dict) -> dict:
    """
    Analyze candidate fit against job requirements.
    
    Args:
        candidate: Dictionary with candidate data (ResumeText, Skills, Education)
        job: Dictionary with job data (JobText, RequiredSkills, Role)
        
    Returns:
        Dictionary with analysis results (role, match_percent, matched_skills, missing_skills)
        
    Raises:
        ResumeAnalysisError: If analysis fails
    """
    try:
        # Validate inputs
        if not isinstance(candidate, dict):
            raise ResumeAnalysisError(f"Candidate must be dict, got {type(candidate).__name__}")

        if not isinstance(job, dict):
            raise ResumeAnalysisError(f"Job must be dict, got {type(job).__name__}")

        if not candidate:
            log_warning(MODULE_NAME, "Received empty candidate dictionary")
            raise ResumeAnalysisError("Candidate data is empty")

        if not job:
            log_warning(MODULE_NAME, "Received empty job dictionary")
            raise ResumeAnalysisError("Job data is empty")

        # Extract resume and job text with fallbacks
        try:
            resume_text = candidate.get("ResumeText", "") or " ".join(
                [candidate.get("Skills", ""), candidate.get("Education", "")]
            )
        except Exception as e:
            log_warning(MODULE_NAME, f"Error extracting resume text: {str(e)}")
            resume_text = ""

        try:
            job_text = job.get("JobText", "") or " ".join(
                [job.get("RequiredSkills", ""), job.get("Description", "")]
            )
        except Exception as e:
            log_warning(MODULE_NAME, f"Error extracting job text: {str(e)}")
            job_text = ""

        # Ensure we have some text to work with
        if not resume_text.strip():
            log_warning(MODULE_NAME, "No resume text available for analysis")
            resume_text = candidate.get("Skills", "")

        if not job_text.strip():
            log_warning(MODULE_NAME, "No job text available for analysis")
            job_text = job.get("RequiredSkills", "")

        # Perform skill matching
        try:
            skill_report = match_skills(
                candidate.get("Skills", ""), job.get("RequiredSkills", "")
            )
        except Exception as e:
            log_warning(MODULE_NAME, f"Error in skill matching: {str(e)}")
            skill_report = {
                "matched_skills": [],
                "missing_skills": [],
                "match_percent": 0.0,
            }

        # Compute overall match score
        try:
            total_score = compute_match_score(resume_text, job_text)
        except Exception as e:
            log_warning(MODULE_NAME, f"Error computing match score: {str(e)}")
            total_score = skill_report["match_percent"]  # Fall back to skill match

        # Compile results
        result = {
            "role": job.get("Role", "Unknown"),
            "match_percent": total_score,
            "matched_skills": skill_report["matched_skills"],
            "missing_skills": skill_report["missing_skills"],
        }

        log_info(
            MODULE_NAME,
            f"Analysis complete for role {job.get('Role', 'Unknown')}: {total_score}% match"
        )
        return result

    except ResumeAnalysisError as e:
        log_error(MODULE_NAME, e, "Resume-job analysis error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in analyze_against_job")
        raise ResumeAnalysisError(f"Failed to analyze candidate against job: {str(e)}")
