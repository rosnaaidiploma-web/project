"""
PDF Report Generation Module
Generates PDF reports for resumes, skill gaps, and training recommendations
Includes comprehensive error handling
"""

import os
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

from .logger import get_logger, log_error, log_warning, log_info
from .exceptions import PDFReportError

# Initialize logger
logger = get_logger()
MODULE_NAME = "PDFReport"

# Output directory for reports
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), os.pardir, "reports")


def generate_pdf(file_name: str, title: str, lines: list) -> str:
    """
    Generate a PDF document with provided content.
    
    Args:
        file_name: Name of PDF file to save
        title: Title of the report
        lines: List of text lines to include in the report
        
    Returns:
        Path to the generated PDF file
        
    Raises:
        PDFReportError: If PDF generation fails
    """
    try:
        # Validate inputs
        if not isinstance(file_name, str) or not file_name.strip():
            raise PDFReportError("File name must be non-empty string")

        if not isinstance(title, str):
            raise PDFReportError(f"Title must be string, got {type(title).__name__}")

        if lines is None:
            raise PDFReportError("Lines list is None")

        if not isinstance(lines, list):
            raise PDFReportError(f"Lines must be list, got {type(lines).__name__}")

        # Validate file extension
        if not file_name.endswith(".pdf"):
            file_name = f"{file_name}.pdf"

        # Create output directory
        try:
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            log_info(MODULE_NAME, f"Output directory ensured: {OUTPUT_DIR}")
        except Exception as e:
            log_error(MODULE_NAME, e, "Error creating output directory")
            raise PDFReportError(f"Cannot create output directory: {str(e)}")

        # Generate file path
        file_path = os.path.join(OUTPUT_DIR, file_name)

        # Create PDF
        try:
            c = canvas.Canvas(file_path, pagesize=letter)
            width, height = letter

            # Set up page
            c.setFont("Helvetica-Bold", 16)
            c.drawString(40, height - 60, title)

            # Write content
            c.setFont("Helvetica", 11)
            y = height - 90

            for i, line in enumerate(lines):
                try:
                    # Ensure line is string
                    if not isinstance(line, str):
                        line = str(line)

                    # Handle long lines
                    if len(line) > 90:
                        # Split long lines
                        words = line.split()
                        current_line = ""
                        for word in words:
                            if len(current_line) + len(word) + 1 > 90:
                                c.drawString(40, y, current_line)
                                y -= 18
                                current_line = word
                            else:
                                current_line += (
                                    " " + word if current_line else word
                                )
                        if current_line:
                            c.drawString(40, y, current_line)
                    else:
                        c.drawString(40, y, line)

                    y -= 18

                    # Create new page if needed
                    if y < 60:
                        c.showPage()
                        c.setFont("Helvetica", 11)
                        y = height - 60

                except Exception as e:
                    log_warning(
                        MODULE_NAME,
                        f"Error writing line {i}: {str(e)}"
                    )
                    continue

            # Add footer with generation timestamp
            try:
                from datetime import datetime
                footer_text = f"Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                c.setFont("Helvetica-Oblique", 9)
                c.drawString(40, 30, footer_text)
            except Exception as e:
                log_warning(MODULE_NAME, f"Error adding footer: {str(e)}")

            # Save PDF
            c.save()
            log_info(MODULE_NAME, f"PDF generated successfully: {file_path}")
            return file_path

        except Exception as e:
            log_error(MODULE_NAME, e, "Error creating PDF with ReportLab")
            raise PDFReportError(f"Failed to create PDF: {str(e)}")

    except PDFReportError as e:
        log_error(MODULE_NAME, e, "PDF generation validation error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in generate_pdf")
        raise PDFReportError(f"Failed to generate PDF: {str(e)}")


def resume_report(
    candidate_name: str,
    job_role: str,
    match_score: float,
    matched_skills: list,
    missing_skills: list,
) -> str:
    """
    Generate resume analysis report PDF.
    
    Args:
        candidate_name: Name of the candidate
        job_role: Target job role
        match_score: Match percentage score
        matched_skills: List of matched skills
        missing_skills: List of missing skills
        
    Returns:
        Path to generated PDF file
        
    Raises:
        PDFReportError: If report generation fails
    """
    try:
        # Validate inputs
        if not isinstance(candidate_name, str) or not candidate_name.strip():
            raise PDFReportError("Candidate name must be non-empty string")

        if not isinstance(job_role, str):
            raise PDFReportError("Job role must be string")

        try:
            match_score = float(match_score)
        except (ValueError, TypeError) as e:
            log_warning(MODULE_NAME, f"Invalid match score: {match_score}")
            match_score = 0.0

        if not isinstance(matched_skills, list):
            matched_skills = []
        if not isinstance(missing_skills, list):
            missing_skills = []

        # Prepare report content
        lines = [
            f"Resume Report for: {candidate_name}",
            f"Matched Role: {job_role}",
            f"Match Score: {match_score}%",
            "",
            "Matched Skills:",
        ]

        # Add matched skills
        if matched_skills:
            lines += [f"- {skill}" for skill in matched_skills]
        else:
            lines.append("- None")

        lines += ["", "Missing Skills:"]

        # Add missing skills
        if missing_skills:
            lines += [f"- {skill}" for skill in missing_skills]
        else:
            lines.append("- None")

        # Generate PDF
        try:
            return generate_pdf("resume_report.pdf", "Resume Analysis Report", lines)
        except Exception as e:
            log_error(MODULE_NAME, e, "Error generating resume report PDF")
            raise PDFReportError(f"Failed to generate resume report: {str(e)}")

    except PDFReportError as e:
        log_error(MODULE_NAME, e, "Resume report generation error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in resume_report")
        raise PDFReportError(f"Failed to create resume report: {str(e)}")


def skill_gap_report(
    candidate_name: str, role: str, missing_skills: list, gap_percent: float
) -> str:
    """
    Generate skill gap analysis report PDF.
    
    Args:
        candidate_name: Name of the candidate
        role: Target role
        missing_skills: List of missing skills
        gap_percent: Gap percentage
        
    Returns:
        Path to generated PDF file
        
    Raises:
        PDFReportError: If report generation fails
    """
    try:
        # Validate inputs
        if not isinstance(candidate_name, str) or not candidate_name.strip():
            raise PDFReportError("Candidate name must be non-empty string")

        if not isinstance(role, str):
            raise PDFReportError("Role must be string")

        try:
            gap_percent = float(gap_percent)
        except (ValueError, TypeError) as e:
            log_warning(MODULE_NAME, f"Invalid gap percentage: {gap_percent}")
            gap_percent = 0.0

        if not isinstance(missing_skills, list):
            missing_skills = []

        # Prepare report content
        lines = [
            f"Skill Gap Report for: {candidate_name}",
            f"Target Role: {role}",
            f"Gap Percentage: {gap_percent}%",
            "",
            "Missing Skills:",
        ]

        # Add missing skills
        if missing_skills:
            lines += [f"- {skill}" for skill in missing_skills]
        else:
            lines.append("- None")

        # Generate PDF
        try:
            return generate_pdf("skill_gap_report.pdf", "Skill Gap Report", lines)
        except Exception as e:
            log_error(MODULE_NAME, e, "Error generating skill gap report PDF")
            raise PDFReportError(f"Failed to generate skill gap report: {str(e)}")

    except PDFReportError as e:
        log_error(MODULE_NAME, e, "Skill gap report generation error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in skill_gap_report")
        raise PDFReportError(f"Failed to create skill gap report: {str(e)}")


def training_report(candidate_name: str, recommendations: list) -> str:
    """
    Generate training recommendations report PDF.
    
    Args:
        candidate_name: Name of the candidate
        recommendations: List of training recommendations
        
    Returns:
        Path to generated PDF file
        
    Raises:
        PDFReportError: If report generation fails
    """
    try:
        # Validate inputs
        if not isinstance(candidate_name, str) or not candidate_name.strip():
            raise PDFReportError("Candidate name must be non-empty string")

        if recommendations is None:
            raise PDFReportError("Recommendations is None")

        if not isinstance(recommendations, list):
            recommendations = []

        # Prepare report content
        lines = [
            f"Training Recommendation Report for: {candidate_name}",
            "",
            "Recommended Courses:",
        ]

        # Add recommendations
        try:
            for item in recommendations:
                try:
                    if isinstance(item, dict):
                        skill = item.get("skill", "Unknown")
                        course = item.get("course", "Available courses")
                        lines.append(f"- {skill}: {course}")
                    else:
                        lines.append(f"- {str(item)}")
                except Exception as e:
                    log_warning(MODULE_NAME, f"Error processing recommendation: {str(e)}")
                    continue
        except Exception as e:
            log_warning(MODULE_NAME, f"Error iterating recommendations: {str(e)}")

        # Generate PDF
        try:
            return generate_pdf(
                "training_report.pdf", "Training Recommendation Report", lines
            )
        except Exception as e:
            log_error(MODULE_NAME, e, "Error generating training report PDF")
            raise PDFReportError(f"Failed to generate training report: {str(e)}")

    except PDFReportError as e:
        log_error(MODULE_NAME, e, "Training report generation error")
        raise
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in training_report")
        raise PDFReportError(f"Failed to create training report: {str(e)}")
