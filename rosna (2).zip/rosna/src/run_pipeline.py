"""
Main Pipeline Orchestrator
Runs the complete HRM system pipeline with error handling
"""

import os
import sys
import pandas as pd
from typing import Optional

# Add root directory to path
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
sys.path.insert(0, ROOT_DIR)

from src.data_preprocessing import (
    preprocess_resume_data,
    preprocess_job_data,
    preprocess_employee_data,
)
from src.ml_model import train_resume_model, load_model, predict_selection
from src.resume_analyzer import analyze_against_job
from src.skill_gap import generate_gap_report
from src.training_recommender import recommend_training
from src.promotion_analysis import compare_employee_to_role
from src.pdf_report import resume_report, skill_gap_report, training_report
from src.logger import get_logger, log_info, log_error, log_warning

# Initialize logger
logger = get_logger()
MODULE_NAME = "Pipeline"

# Data paths
DATA_DIR = os.path.join(ROOT_DIR, "data")
MODEL_PATH = os.path.join(ROOT_DIR, "models", "model.pkl")


def run_training_pipeline() -> bool:
    """
    Run the complete HRM training pipeline.
    
    Returns:
        True if pipeline completes successfully, False otherwise
    """
    try:
        log_info(MODULE_NAME, "Starting HRM training pipeline...")

        # Define data paths
        resume_path = os.path.join(DATA_DIR, "old_resume_dataset.csv")
        job_path = os.path.join(DATA_DIR, "job_dataset.csv")
        employee_path = os.path.join(DATA_DIR, "employee_dataset.csv")

        # Validate paths exist
        required_files = {
            "resume_dataset": resume_path,
            "job_dataset": job_path,
            "employee_dataset": employee_path,
        }

        for file_name, file_path in required_files.items():
            if not os.path.exists(file_path):
                error_msg = f"Required file not found: {file_path}"
                log_error(MODULE_NAME, FileNotFoundError(), error_msg)
                print(f"ERROR: {error_msg}")
                return False

        # Load datasets
        print("\n📂 Loading datasets...")
        log_info(MODULE_NAME, "Loading datasets...")
        try:
            resumes = pd.read_csv(resume_path)
            jobs = pd.read_csv(job_path)
            employees = pd.read_csv(employee_path)
            log_info(
                MODULE_NAME,
                f"Datasets loaded: {len(resumes)} resumes, {len(jobs)} jobs, {len(employees)} employees"
            )
            print(f"✓ Loaded {len(resumes)} resumes, {len(jobs)} jobs, {len(employees)} employees")
        except Exception as e:
            log_error(MODULE_NAME, e, "Error loading datasets")
            print(f"ERROR: Failed to load datasets - {str(e)}")
            return False

        # Preprocess datasets
        print("\n🧹 Preprocessing datasets...")
        log_info(MODULE_NAME, "Preprocessing datasets...")
        try:
            resumes = preprocess_resume_data(resumes)
            log_info(MODULE_NAME, f"Preprocessed {len(resumes)} resume records")
            print(f"✓ Preprocessed {len(resumes)} resume records")
        except Exception as e:
            log_error(MODULE_NAME, e, "Error preprocessing resume data")
            print(f"ERROR: Failed to preprocess resumes - {str(e)}")
            return False

        try:
            jobs = preprocess_job_data(jobs)
            log_info(MODULE_NAME, f"Preprocessed {len(jobs)} job records")
            print(f"✓ Preprocessed {len(jobs)} job records")
        except Exception as e:
            log_error(MODULE_NAME, e, "Error preprocessing job data")
            print(f"ERROR: Failed to preprocess jobs - {str(e)}")
            return False

        try:
            employees = preprocess_employee_data(employees)
            log_info(MODULE_NAME, f"Preprocessed {len(employees)} employee records")
            print(f"✓ Preprocessed {len(employees)} employee records")
        except Exception as e:
            log_error(MODULE_NAME, e, "Error preprocessing employee data")
            print(f"ERROR: Failed to preprocess employees - {str(e)}")
            return False

        # Train model
        print("\n🧠 Training machine learning model...")
        log_info(MODULE_NAME, "Training ML model...")
        try:
            results = train_resume_model(resume_path, save_path=MODEL_PATH)
            best_accuracy = results.get("best_accuracy", 0.0)
            log_info(MODULE_NAME, f"Model training complete. Best accuracy: {best_accuracy}")
            print(f"✓ Best model accuracy: {best_accuracy}")

            # Show model evaluation details
            evaluation = results.get("evaluation", {})
            for model_name, metrics in evaluation.items():
                accuracy = metrics.get("accuracy", 0.0)
                print(f"  - {model_name}: {accuracy}")

        except Exception as e:
            log_error(MODULE_NAME, e, "Error training ML model")
            print(f"ERROR: Failed to train model - {str(e)}")
            return False

        # Test resume analysis
        print("\n📄 Testing resume analysis...")
        if not resumes.empty and not jobs.empty:
            try:
                sample_candidate = resumes.iloc[0].to_dict()
                best_job = jobs.iloc[0].to_dict()
                analysis = analyze_against_job(sample_candidate, best_job)
                match_percent = analysis.get("match_percent", 0.0)
                log_info(
                    MODULE_NAME,
                    f"Sample analysis: {match_percent}% match for {best_job.get('Role')}"
                )
                print(
                    f"✓ Sample resume vs {best_job.get('Role')}: {match_percent}% match"
                )
            except Exception as e:
                log_warning(MODULE_NAME, f"Error testing resume analysis: {str(e)}")
                print(f"⚠ Resume analysis test failed - {str(e)}")
        else:
            log_warning(MODULE_NAME, "Insufficient data for resume analysis test")

        # Test skill gap detection
        print("\n🎯 Testing skill gap detection...")
        if not resumes.empty and not jobs.empty:
            try:
                sample_candidate = resumes.iloc[0].to_dict()
                best_job = jobs.iloc[0].to_dict()
                gap = generate_gap_report(
                    sample_candidate.get("Name", "Candidate"),
                    sample_candidate.get("Skills", ""),
                    best_job.get("RequiredSkills", ""),
                    best_job.get("Role", ""),
                )
                gap_percent = gap.get("GapPercentage", 0.0)
                log_info(MODULE_NAME, f"Sample skill gap: {gap_percent}%")
                print(f"✓ Sample skill gap: {gap_percent}%")
            except Exception as e:
                log_warning(MODULE_NAME, f"Error testing skill gap: {str(e)}")
                print(f"⚠ Skill gap test failed - {str(e)}")
        else:
            log_warning(MODULE_NAME, "Insufficient data for skill gap test")

        # Test training recommendations
        print("\n📚 Testing training recommendations...")
        if not resumes.empty and not jobs.empty:
            try:
                sample_candidate = resumes.iloc[0].to_dict()
                best_job = jobs.iloc[0].to_dict()
                gap = generate_gap_report(
                    sample_candidate.get("Name", "Candidate"),
                    sample_candidate.get("Skills", ""),
                    best_job.get("RequiredSkills", ""),
                    best_job.get("Role", ""),
                )
                missing_skills = gap.get("MissingSkills", [])
                recommendations = recommend_training(missing_skills)
                log_info(MODULE_NAME, f"Generated {len(recommendations)} recommendations")
                print(f"✓ Generated {len(recommendations)} training recommendations:")
                for item in recommendations[:5]:  # Show first 5
                    print(f"  - {item.get('skill')}: {item.get('course')}")
                if len(recommendations) > 5:
                    print(f"  ... and {len(recommendations) - 5} more")
            except Exception as e:
                log_warning(MODULE_NAME, f"Error testing recommendations: {str(e)}")
                print(f"⚠ Training recommendation test failed - {str(e)}")
        else:
            log_warning(MODULE_NAME, "Insufficient data for recommendations test")

        # Generate PDF reports
        print("\n📑 Generating PDF reports...")
        if not resumes.empty and not jobs.empty:
            report_count = 0
            try:
                sample_candidate = resumes.iloc[0].to_dict()
                best_job = jobs.iloc[0].to_dict()
                analysis = analyze_against_job(sample_candidate, best_job)

                # Generate resume report
                try:
                    resume_report_path = resume_report(
                        sample_candidate.get("Name", "Candidate"),
                        best_job.get("Role", ""),
                        analysis.get("match_percent", 0.0),
                        analysis.get("matched_skills", []),
                        analysis.get("missing_skills", []),
                    )
                    log_info(MODULE_NAME, f"Resume report generated: {resume_report_path}")
                    report_count += 1
                except Exception as e:
                    log_warning(MODULE_NAME, f"Error generating resume report: {str(e)}")
                    print(f"⚠ Resume report generation failed - {str(e)}")

                # Generate skill gap report
                try:
                    gap = generate_gap_report(
                        sample_candidate.get("Name", "Candidate"),
                        sample_candidate.get("Skills", ""),
                        best_job.get("RequiredSkills", ""),
                        best_job.get("Role", ""),
                    )
                    gap_report_path = skill_gap_report(
                        sample_candidate.get("Name", "Candidate"),
                        best_job.get("Role", ""),
                        gap.get("MissingSkills", []),
                        gap.get("GapPercentage", 0.0),
                    )
                    log_info(MODULE_NAME, f"Skill gap report generated: {gap_report_path}")
                    report_count += 1
                except Exception as e:
                    log_warning(MODULE_NAME, f"Error generating skill gap report: {str(e)}")
                    print(f"⚠ Skill gap report generation failed - {str(e)}")

                # Generate training report
                try:
                    recommendations = recommend_training(gap.get("MissingSkills", []))
                    training_report_path = training_report(
                        sample_candidate.get("Name", "Candidate"),
                        recommendations,
                    )
                    log_info(MODULE_NAME, f"Training report generated: {training_report_path}")
                    report_count += 1
                except Exception as e:
                    log_warning(MODULE_NAME, f"Error generating training report: {str(e)}")
                    print(f"⚠ Training report generation failed - {str(e)}")

                print(f"✓ Generated {report_count}/3 PDF reports")

            except Exception as e:
                log_error(MODULE_NAME, e, "Error in PDF report generation")
                print(f"⚠ PDF report generation had errors - {str(e)}")
        else:
            log_warning(MODULE_NAME, "Insufficient data for PDF reports")

        # Final summary
        print("\n" + "=" * 60)
        print("✅ HRM TRAINING PIPELINE COMPLETED SUCCESSFULLY")
        print("=" * 60)
        print(f"📊 Model saved at: {MODEL_PATH}")
        print(f"📁 Reports saved at: {os.path.join(ROOT_DIR, 'reports')}")
        print(f"📋 Logs saved at: {os.path.join(ROOT_DIR, 'logs', 'error.log')}")
        log_info(MODULE_NAME, "Pipeline completed successfully")

        return True

    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in pipeline")
        print(f"FATAL ERROR: {str(e)}")
        return False


if __name__ == "__main__":
    success = run_training_pipeline()
    sys.exit(0 if success else 1)
