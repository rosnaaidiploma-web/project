# Error Handling & Logging Documentation

## 📋 Overview

This document explains the comprehensive error handling and logging system implemented in the AI-Driven HRM System. The system is designed to be robust, user-friendly, and production-ready with zero crashes and proper error tracking.

---

## 🏗️ Architecture

### Components

1. **`logger.py`** - Centralized logging configuration
2. **`exceptions.py`** - Custom exception classes
3. **Module-level error handling** - try-except blocks in all modules
4. **Flask error handlers** - Global exception handling in web app
5. **Logging files** - `logs/error.log` for persistent error tracking

---

## 📝 Logging System

### Logger Configuration

The `HRMLogger` class provides singleton pattern logging to ensure consistent logging across the application.

**Features:**
- Dual output (file + console)
- File logging: All messages (DEBUG and above)
- Console logging: Warnings and above only
- Timestamp, module name, function, and line number included
- UTF-8 encoding for special characters

### Using the Logger

```python
from src.logger import get_logger, log_error, log_warning, log_info

# Initialize logger
logger = get_logger()
MODULE_NAME = "MyModule"

# Log error
log_error(MODULE_NAME, error_object, "Context about the error")

# Log warning
log_warning(MODULE_NAME, "Warning message")

# Log info
log_info(MODULE_NAME, "Info message")

# Log debug
log_debug(MODULE_NAME, "Debug message")
```

### Log File Location

All logs are saved to: `logs/error.log`

**Log Format:**
```
2024-04-27 10:30:45 - HRM_System - ERROR - [ml_model.py:150] - train_resume_model() - [MLModel] Error training ML model: Failed to read CSV file: [Error details]
```

---

## ⚠️ Exception Hierarchy

### Custom Exceptions

All exceptions inherit from `HRMException` base class:

```python
HRMException (Base)
├── DataValidationError       # Data validation failures
├── FileHandlingError         # File operation errors
├── ResumeAnalysisError       # Resume processing errors
├── ModelError               # ML model errors
├── SkillGapError            # Skill gap calculation errors
├── PromotionAnalysisError   # Promotion analysis errors
├── TrainingRecommendationError # Training recommendation errors
├── ChatbotError             # Chatbot processing errors
├── PDFReportError           # PDF generation errors
└── ConfigurationError       # Configuration errors
```

### Benefits

- **Type-specific error handling** - Catch specific error types
- **Clear error context** - Each exception type indicates the problem source
- **Custom messages** - Descriptive error messages for debugging
- **Graceful degradation** - System continues running even when components fail

---

## 🔍 Error Handling Patterns

### Pattern 1: Try-Except with Logging

```python
def process_data(data):
    try:
        # Validate input
        if data is None:
            raise DataValidationError("Data is None")
        
        if not isinstance(data, dict):
            raise DataValidationError(f"Expected dict, got {type(data).__name__}")
        
        # Process data
        result = data['key']
        
    except DataValidationError as e:
        log_error(MODULE_NAME, e, "Data validation failed")
        raise  # Re-raise for caller to handle
    
    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in process_data")
        raise DataProcessingError(f"Failed to process data: {str(e)}")
```

### Pattern 2: Fallback Values

```python
def extract_value(obj, key, default_value=None):
    try:
        value = obj.get(key)
        if value is None:
            return default_value
        return value
    except Exception as e:
        log_warning(MODULE_NAME, f"Error extracting {key}: {str(e)}")
        return default_value
```

### Pattern 3: Safe Resource Cleanup

```python
def process_file(file_path):
    file_handle = None
    try:
        file_handle = open(file_path, 'r')
        content = file_handle.read()
        return content
    except FileNotFoundError as e:
        log_error(MODULE_NAME, e, f"File not found: {file_path}")
        raise FileHandlingError(f"Cannot find file: {file_path}")
    finally:
        if file_handle:
            file_handle.close()
```

### Pattern 4: Input Validation

```python
def predict_candidate(resume_text, experience=0.0):
    # Validate types
    if not isinstance(resume_text, str):
        raise DataValidationError("Resume must be string")
    
    # Validate content
    if not resume_text.strip():
        raise DataValidationError("Resume is empty")
    
    # Validate numeric ranges
    try:
        experience = float(experience)
    except (ValueError, TypeError):
        raise DataValidationError("Experience must be numeric")
    
    if experience < 0:
        log_warning(MODULE_NAME, "Negative experience - resetting to 0")
        experience = 0.0
    
    # Process...
```

---

## 🔐 Module-Specific Error Handling

### 1. Data Preprocessing (`data_preprocessing.py`)

**Common Errors:**
- Missing columns in dataset
- Invalid data types
- Null/empty values
- NLTK data missing

**Handling:**
```python
# Validates required columns
if missing_cols:
    log_warning(MODULE_NAME, f"Missing columns: {missing_cols}")

# Handles conversion errors gracefully
df["Experience"] = pd.to_numeric(df["Experience"], errors="coerce")

# Falls back to empty string on error
df["Text"] = df["Text"].apply(clean_text)  # Returns "" on error
```

### 2. Resume Analyzer (`resume_analyzer.py`)

**Common Errors:**
- Empty resume text
- Invalid format
- NLP processing failures
- Empty skill sets

**Handling:**
```python
# Returns safe defaults on failure
if not resume_text.strip():
    raise ResumeAnalysisError("Resume text is empty")

# Handles NLP exceptions
try:
    cleaned_text = clean_text(full_text)
except Exception as e:
    log_error(MODULE_NAME, e, "Error cleaning resume text")
    cleaned_text = ""  # Continue with empty
```

### 3. Machine Learning (`ml_model.py`)

**Common Errors:**
- Model file not found
- Invalid data shape for prediction
- Training dataset issues
- Prediction errors

**Handling:**
```python
# Validates model path
if not os.path.exists(model_path):
    raise FileNotFoundError(f"Model not found: {model_path}")

# Handles prediction errors
try:
    prediction = model.predict(data)[0]
except Exception as e:
    log_error(MODULE_NAME, e, "Prediction failed")
    raise ModelError(f"Prediction failed: {str(e)}")

# Validates training data
if df.empty:
    raise DataValidationError("Dataset is empty")
```

### 4. Skill Gap Detection (`skill_gap.py`)

**Common Errors:**
- Empty skill sets
- Parsing failures
- Division by zero

**Handling:**
```python
# Handles empty sets
if required_set:
    gap_percentage = round(len(missing) / len(required_set) * 100, 2)
else:
    gap_percentage = 0.0

# Continues on parsing failure
try:
    candidate_set = {skill.lower() for skill in split_skills(skills)}
except Exception as e:
    log_warning(MODULE_NAME, f"Error parsing skills: {str(e)}")
    candidate_set = set()
```

### 5. PDF Report Generation (`pdf_report.py`)

**Common Errors:**
- Directory creation failure
- File write permissions
- Invalid content
- Long text handling

**Handling:**
```python
# Creates directory safely
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Handles long text by wrapping
if len(line) > 90:
    # Split and wrap the line
    words = line.split()
    # ... word wrapping logic

# Validates file names
if not file_name.endswith(".pdf"):
    file_name = f"{file_name}.pdf"
```

### 6. Chatbot (`chatbot.py`)

**Common Errors:**
- Intent file not found
- Invalid JSON format
- Empty responses
- Processing failures

**Handling:**
```python
# Validates file existence
if not os.path.exists(INTENTS_PATH):
    raise ChatbotError(f"Intents file not found: {INTENTS_PATH}")

# Handles JSON parsing errors
try:
    data = json.load(file)
except json.JSONDecodeError as e:
    log_error(MODULE_NAME, e, "Invalid JSON")
    raise ChatbotError(f"Invalid JSON: {str(e)}")

# Falls back to default response
if not responses:
    return DEFAULT_RESPONSE
```

### 7. Flask Web Application (`web_app/app.py`)

**Common Errors:**
- Missing template files
- Database connection failures
- File upload issues
- Route errors

**Handling:**
```python
@app.errorhandler(404)
def not_found_error(error):
    log_warning(MODULE_NAME, f"404 error: {request.path}")
    return render_template("404.html"), 404

@app.errorhandler(500)
def internal_error(error):
    log_error(MODULE_NAME, error, "500 Internal Server Error")
    return render_template("500.html"), 500

@app.errorhandler(Exception)
def handle_exception(error):
    log_error(MODULE_NAME, error, "Unhandled exception")
    flash("An error occurred. Please try again.", "error")
    return redirect(url_for("index")), 500
```

---

## 🛡️ Best Practices

### 1. Validation First

```python
# GOOD: Validate early
if not isinstance(data, dict):
    raise TypeError("Expected dict")

# BAD: Assume data is valid
value = data['key']  # May crash
```

### 2. Meaningful Error Messages

```python
# GOOD: Clear, actionable message
raise DataValidationError("Resume must be non-empty string, got empty input")

# BAD: Vague message
raise Exception("Error")
```

### 3. Avoid Bare Except

```python
# GOOD: Specific exception handling
try:
    result = process()
except ValueError as e:
    log_error(MODULE_NAME, e, "Invalid value")
    raise

# BAD: Catches all exceptions silently
try:
    result = process()
except:
    pass  # Silent failure - NEVER DO THIS
```

### 4. Log Context

```python
# GOOD: Contextual logging
log_error(MODULE_NAME, error, "Failed to load model from /path/to/model.pkl")

# BAD: Generic logging
log_error(MODULE_NAME, error, "Error")
```

### 5. Graceful Degradation

```python
# GOOD: Continue with fallback
try:
    model = load_model(model_path)
except Exception as e:
    log_warning(MODULE_NAME, f"Model unavailable: {str(e)}")
    model = None  # Continue without model

# BAD: Crash the application
model = load_model(model_path)  # Crashes if model missing
```

---

## 📊 Error Handling Statistics

### Common Errors by Module

| Module | Error Type | Frequency | Solution |
|--------|-----------|-----------|----------|
| data_preprocessing | Missing columns | Medium | Validate before processing |
| resume_analyzer | Empty text | High | Provide default values |
| ml_model | Model not found | Medium | Check path before loading |
| chatbot | Intent file missing | Low | Create default intents |
| flask | File upload error | Medium | Validate file size/type |

### Recovery Strategies

| Error Type | Strategy | Example |
|------------|----------|---------|
| File not found | Provide fallback data | Use empty DataFrame |
| Parsing failure | Use default value | Return empty string |
| Computation error | Use safe alternative | Skip step, continue |
| Model unavailable | Disable feature | Show "Model not loaded" |
| Invalid input | Reject with message | Raise validation error |

---

## 🧪 Testing Error Scenarios

### Unit Tests for Error Handling

```python
def test_empty_resume_handling():
    """Test that empty resume is handled gracefully"""
    with pytest.raises(ResumeAnalysisError):
        extract_resume_fields("")

def test_missing_model_handling():
    """Test that missing model returns safe error"""
    with pytest.raises(FileNotFoundError):
        load_model("/nonexistent/path")

def test_data_validation():
    """Test that invalid data is rejected"""
    with pytest.raises(DataValidationError):
        preprocess_resume_data(None)
```

---

## 🔧 Debugging in VS Code

### 1. View Error Logs

```bash
# Terminal
tail -f logs/error.log

# Or in VS Code
Ctrl+` -> Open logs/error.log
```

### 2. Enable Debug Logging

```python
# In logger.py
logger = logging.getLogger("HRM_System")
logger.setLevel(logging.DEBUG)  # More verbose output
```

### 3. Breakpoint Debugging

```python
# In VS Code, click on line number to set breakpoint
def problematic_function():
    x = 5  # Breakpoint here
    y = x / 0  # Error will be caught
```

### 4. Exception Breakpoint

In VS Code debugger:
- Shift+Ctrl+D (Open Debug panel)
- Enable "Exception breakpoint" → breaks on all exceptions

---

## 📋 Troubleshooting Common Issues

### Issue 1: "Module not found" Error

**Cause:** Import path issues
**Solution:**
```python
# Add to path
import sys
sys.path.insert(0, ROOT_DIR)
```

### Issue 2: "NoneType has no attribute" Error

**Cause:** Null reference
**Solution:**
```python
# Add null checks
if data is not None:
    process(data)
```

### Issue 3: "CSV file not found" Error

**Cause:** Incorrect file path
**Solution:**
```python
# Validate path exists
if not os.path.exists(csv_path):
    raise FileNotFoundError(f"File not found: {csv_path}")
```

### Issue 4: "Model prediction failed" Error

**Cause:** Invalid input shape or missing model
**Solution:**
```python
# Check model exists and validate input
if model is None:
    raise ModelError("Model not loaded")
if not isinstance(resume_text, str):
    raise DataValidationError("Resume must be string")
```

---

## 🚀 Production Deployment

### Before Deployment

- [ ] All modules tested for error handling
- [ ] Logs directory exists and is writable
- [ ] Environment variables configured
- [ ] Error handlers registered in Flask
- [ ] Database connections tested
- [ ] File paths validated

### Monitoring

```bash
# Monitor logs in real-time
tail -f logs/error.log | grep ERROR

# Count errors by type
grep ERROR logs/error.log | wc -l

# Find specific errors
grep "ResumeAnalysisError" logs/error.log
```

---

## 📞 Support & Escalation

If errors persist:

1. **Check error.log** - First source of truth
2. **Verify paths** - Ensure data files exist
3. **Check permissions** - Verify read/write access
4. **Review logs** - Look for patterns
5. **Test individually** - Isolate problematic module
6. **Contact support** - Provide error.log excerpt

---

## 📚 References

- Python Error Handling: https://docs.python.org/3/tutorial/errors.html
- Logging Module: https://docs.python.org/3/library/logging.html
- Flask Error Handling: https://flask.palletsprojects.com/errorhandling/
- Custom Exceptions: https://docs.python.org/3/tutorial/errors.html#defining-clean-up-actions

---

**Document Updated:** April 27, 2024
**Version:** 1.0
**Status:** Production Ready
