"""
Flask Web Application for HRM System
Provides UI for candidates and HR staff with comprehensive error handling
"""

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    send_from_directory,
    flash,
    jsonify,
)
import os
import sys
import pandas as pd
import traceback

# Set up path
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
sys.path.insert(0, ROOT_DIR)

# Import modules
from src.data_preprocessing import preprocess_job_data
from src.resume_analyzer import analyze_against_job, extract_resume_fields
from src.ml_model import load_model, predict_selection, train_resume_model
from src.skill_gap import generate_gap_report
from src.training_recommender import recommend_training
from src.chatbot import get_chatbot_response
from src.pdf_report import resume_report, skill_gap_report, training_report
from src.logger import get_logger, log_error, log_warning, log_info

# Initialize Flask app
app = Flask(__name__)
app.secret_key = "supersecretkey"

# Initialize logger
logger = get_logger()
MODULE_NAME = "FlaskApp"

# Path configuration
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
DATA_DIR = os.path.join(BASE_DIR, "data")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
MODEL_PATH = os.path.join(BASE_DIR, "models", "model.pkl")


# Error Handlers
@app.errorhandler(404)
def not_found_error(error):
    """Handle 404 errors (page not found)"""
    log_warning(MODULE_NAME, f"404 error: {request.path}")
    return render_template("404.html"), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors (internal server error)"""
    log_error(MODULE_NAME, error, "500 Internal Server Error")
    return render_template("500.html"), 500


@app.errorhandler(Exception)
def handle_exception(error):
    """Global exception handler"""
    log_error(MODULE_NAME, error, f"Unhandled exception in {request.path}")
    if request.is_json:
        return jsonify({"error": "An error occurred processing your request"}), 500
    flash("An error occurred. Please try again.", "error")
    return redirect(url_for("index")), 500


# Utility Functions
def load_jobs() -> pd.DataFrame:
    """
    Load and preprocess jobs dataset.
    
    Returns:
        Preprocessed jobs DataFrame
        
    Raises:
        Exception: If loading fails
    """
    try:
        job_path = os.path.join(DATA_DIR, "job_dataset.csv")

        if not os.path.exists(job_path):
            log_error(
                MODULE_NAME, FileNotFoundError(),
                f"Job dataset not found at {job_path}"
            )
            raise FileNotFoundError(f"Job dataset not found: {job_path}")

        jobs = pd.read_csv(job_path)

        if jobs.empty:
            log_warning(MODULE_NAME, "Job dataset is empty")
            raise ValueError("Job dataset is empty")

        jobs = preprocess_job_data(jobs)
        log_info(MODULE_NAME, f"Loaded {len(jobs)} jobs")
        return jobs

    except Exception as e:
        log_error(MODULE_NAME, e, "Error loading jobs")
        raise


def load_model_safe():
    """
    Safely load the trained model.
    
    Returns:
        Loaded model or None if loading fails
    """
    try:
        if not os.path.exists(MODEL_PATH):
            log_warning(MODULE_NAME, f"Model file not found at {MODEL_PATH}")
            return None

        model = load_model(MODEL_PATH)
        log_info(MODULE_NAME, "Model loaded successfully")
        return model

    except Exception as e:
        log_error(MODULE_NAME, e, "Error loading model")
        return None


# Routes
@app.route("/")
def index():
    """Home page route"""
    try:
        jobs = load_jobs().to_dict(orient="records")
        return render_template("index.html", jobs=jobs)
    except Exception as e:
        log_error(MODULE_NAME, e, "Error in index route")
        flash("Error loading home page. Please try again.", "error")
        return render_template("index.html", jobs=[])


@app.route("/candidate")
def candidate_dashboard():
    """Candidate dashboard route"""
    try:
        jobs = load_jobs().to_dict(orient="records")
        return render_template("candidate_dashboard.html", jobs=jobs)
    except Exception as e:
        log_error(MODULE_NAME, e, "Error in candidate dashboard route")
        flash("Error loading candidate dashboard. Please try again.", "error")
        return render_template("candidate_dashboard.html", jobs=[])


@app.route("/analyze_resume", methods=["POST"])
def analyze_resume():
    """Analyze resume against job requirements"""
    try:
        # Extract form data
        resume_text = request.form.get("resume_text", "").strip()
        selected_role = request.form.get("job_role", "").strip()
        experience = request.form.get("experience", "0").strip()

        # Validate experience
        try:
            experience_value = float(experience) if experience else 0.0
            if experience_value < 0:
                experience_value = 0.0
        except (ValueError, TypeError) as e:
            log_warning(MODULE_NAME, f"Invalid experience value: {experience}")
            experience_value = 0.0

        # Check for resume file upload
        if request.files.get("resume_file"):
            try:
                resume_file = request.files["resume_file"]
                if resume_file and resume_file.filename:
                    # Validate file size (max 1MB)
                    if len(resume_file.read()) > 1024 * 1024:
                        flash("Resume file is too large (max 1MB)", "error")
                        return redirect(url_for("candidate_dashboard"))

                    # Reset file pointer
                    resume_file.seek(0)

                    # Read file content
                    try:
                        resume_text = resume_file.read().decode("utf-8", errors="ignore")
                    except Exception as e:
                        log_warning(MODULE_NAME, f"Error reading resume file: {str(e)}")
                        flash("Error reading resume file. Please paste text instead.", "error")
                        return redirect(url_for("candidate_dashboard"))

            except Exception as e:
                log_error(MODULE_NAME, e, "Error processing resume file upload")
                flash("Error processing resume file.", "error")
                return redirect(url_for("candidate_dashboard"))

        # Validate resume text
        if not resume_text:
            flash("Please enter your resume text.", "error")
            return redirect(url_for("candidate_dashboard"))

        # Extract resume fields
        try:
            candidate = extract_resume_fields(resume_text)
            candidate["Experience"] = experience_value
        except Exception as e:
            log_error(MODULE_NAME, e, "Error extracting resume fields")
            flash("Error processing resume. Please check format.", "error")
            return redirect(url_for("candidate_dashboard"))

        # Load jobs
        try:
            job_data = load_jobs()
            if job_data.empty:
                flash("No jobs available for matching.", "error")
                return redirect(url_for("candidate_dashboard"))
        except Exception as e:
            log_error(MODULE_NAME, e, "Error loading jobs for analysis")
            flash("Error loading job data.", "error")
            return redirect(url_for("candidate_dashboard"))

        # Get selected job
        try:
            if selected_role:
                selected_job = job_data[
                    job_data["Role"] == selected_role
                ].to_dict(orient="records")
                selected_job = (
                    selected_job[0] if selected_job else job_data.iloc[0].to_dict()
                )
            else:
                selected_job = job_data.iloc[0].to_dict()
        except Exception as e:
            log_error(MODULE_NAME, e, "Error selecting job")
            flash("Error selecting job.", "error")
            return redirect(url_for("candidate_dashboard"))

        # Analyze resume
        analysis_results = {}
        try:
            analysis = analyze_against_job(candidate, selected_job)
            analysis_results = analysis
        except Exception as e:
            log_error(MODULE_NAME, e, "Error analyzing resume")
            flash("Error analyzing resume.", "error")
            analysis_results = {
                "role": selected_job.get("Role", "Unknown"),
                "match_percent": 0.0,
                "matched_skills": [],
                "missing_skills": [],
            }

        # Generate skill gap report
        gap_results = {}
        try:
            gap = generate_gap_report(
                candidate.get("Name", "Candidate"),
                candidate.get("Skills", ""),
                selected_job.get("RequiredSkills", ""),
                selected_job.get("Role", "Unknown"),
            )
            gap_results = gap
        except Exception as e:
            log_error(MODULE_NAME, e, "Error generating skill gap report")
            flash("Error generating skill gap report.", "error")
            gap_results = {
                "Name": candidate.get("Name", "Candidate"),
                "Role": selected_job.get("Role", "Unknown"),
                "MissingSkills": [],
                "GapPercentage": 0.0,
                "Summary": "Unable to generate gap report",
            }

        # Get training recommendations
        recommendations = []
        try:
            recommendations = recommend_training(gap_results.get("MissingSkills", []))
        except Exception as e:
            log_error(MODULE_NAME, e, "Error generating training recommendations")
            # Continue without recommendations

        # Get model prediction
        selection_info = {"prediction": None, "probability": None}
        try:
            model = load_model_safe()
            if model:
                candidate_text = " ".join(
                    [candidate.get("Skills", ""), candidate.get("ResumeText", "")]
                )
                try:
                    prediction = predict_selection(
                        candidate_text, experience_value, model=model
                    )
                    selection_info = prediction
                except Exception as e:
                    log_warning(MODULE_NAME, f"Error making prediction: {str(e)}")
        except Exception as e:
            log_error(MODULE_NAME, e, "Error in model prediction")

        # Generate PDF reports
        report_files = {
            "resume_report": None,
            "gap_report": None,
            "training_report": None,
        }

        try:
            resume_path = resume_report(
                candidate.get("Name", "Candidate"),
                selected_job.get("Role", ""),
                analysis_results.get("match_percent", 0.0),
                analysis_results.get("matched_skills", []),
                analysis_results.get("missing_skills", []),
            )
            report_files["resume_report"] = os.path.basename(resume_path)
        except Exception as e:
            log_warning(MODULE_NAME, f"Error generating resume report: {str(e)}")

        try:
            gap_path = skill_gap_report(
                candidate.get("Name", "Candidate"),
                selected_job.get("Role", ""),
                gap_results.get("MissingSkills", []),
                gap_results.get("GapPercentage", 0.0),
            )
            report_files["gap_report"] = os.path.basename(gap_path)
        except Exception as e:
            log_warning(MODULE_NAME, f"Error generating gap report: {str(e)}")

        try:
            training_path = training_report(
                candidate.get("Name", "Candidate"), recommendations
            )
            report_files["training_report"] = os.path.basename(training_path)
        except Exception as e:
            log_warning(MODULE_NAME, f"Error generating training report: {str(e)}")

        return render_template(
            "results.html",
            candidate=candidate,
            job=selected_job,
            analysis=analysis_results,
            gap=gap_results,
            recommendations=recommendations,
            selection_info=selection_info,
            resume_report=report_files["resume_report"],
            gap_report=report_files["gap_report"],
            training_report=report_files["training_report"],
        )

    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in analyze_resume")
        flash("An unexpected error occurred. Please try again.", "error")
        return redirect(url_for("candidate_dashboard"))


@app.route("/hr")
def hr_dashboard():
    """HR dashboard route"""
    try:
        jobs = load_jobs().to_dict(orient="records")
        model = load_model_safe()
        model_status = (
            "✓ Model Loaded"
            if model
            else "⚠ Model not found. Please train the model first."
        )
        return render_template("hr_dashboard.html", jobs=jobs, model_status=model_status)
    except Exception as e:
        log_error(MODULE_NAME, e, "Error in HR dashboard route")
        flash("Error loading HR dashboard.", "error")
        return render_template(
            "hr_dashboard.html",
            jobs=[],
            model_status="⚠ Error loading dashboard",
        )


@app.route("/train_model", methods=["POST"])
def train_model():
    """Train the ML model"""
    try:
        log_info(MODULE_NAME, "Starting model training from HR dashboard")

        resume_path = os.path.join(DATA_DIR, "old_resume_dataset.csv")

        if not os.path.exists(resume_path):
            log_error(
                MODULE_NAME, FileNotFoundError(),
                f"Resume dataset not found: {resume_path}"
            )
            flash(
                "Training dataset not found. Please check data files.", "error"
            )
            return redirect(url_for("hr_dashboard"))

        try:
            results = train_resume_model(resume_path, save_path=MODEL_PATH)
            best_accuracy = results.get("best_accuracy", 0.0)
            flash(
                f"✓ Model trained successfully! Best accuracy: {best_accuracy}",
                "success",
            )
            log_info(MODULE_NAME, f"Model training completed with accuracy: {best_accuracy}")
        except Exception as e:
            log_error(MODULE_NAME, e, "Error during model training")
            flash(f"⚠ Training failed: {str(e)}", "error")

    except Exception as e:
        log_error(MODULE_NAME, e, "Unexpected error in train_model route")
        flash("An error occurred during training.", "error")

    return redirect(url_for("hr_dashboard"))


@app.route("/chatbot", methods=["GET", "POST"])
def chatbot_route():
    """Chatbot interface route"""
    reply = None
    user_message = ""

    try:
        if request.method == "POST":
            user_message = request.form.get("message", "").strip()

            if not user_message:
                flash("Please enter a message.", "error")
            else:
                try:
                    reply = get_chatbot_response(user_message)
                    log_info(MODULE_NAME, f"Chatbot response generated")
                except Exception as e:
                    log_error(MODULE_NAME, e, "Error getting chatbot response")
                    reply = (
                        "Sorry, I encountered an error. "
                        "Please try again."
                    )
                    flash("Error getting response from chatbot.", "error")

        return render_template(
            "chatbot.html", reply=reply, user_message=user_message
        )

    except Exception as e:
        log_error(MODULE_NAME, e, "Error in chatbot route")
        flash("Error loading chatbot.", "error")
        return render_template("chatbot.html", reply=None, user_message="")


@app.route("/reports/<path:filename>")
def download_report(filename):
    """Download generated PDF reports"""
    try:
        # Validate filename to prevent directory traversal
        if ".." in filename or filename.startswith("/"):
            log_warning(MODULE_NAME, f"Suspicious filename requested: {filename}")
            flash("Invalid file requested.", "error")
            return redirect(url_for("candidate_dashboard")), 403

        # Check if file exists
        file_path = os.path.join(REPORTS_DIR, filename)
        if not os.path.exists(file_path):
            log_warning(MODULE_NAME, f"Report file not found: {filename}")
            flash("Report file not found.", "error")
            return redirect(url_for("candidate_dashboard")), 404

        # Send file
        return send_from_directory(REPORTS_DIR, filename, as_attachment=True)

    except Exception as e:
        log_error(MODULE_NAME, e, f"Error downloading report: {filename}")
        flash("Error downloading report.", "error")
        return redirect(url_for("candidate_dashboard")), 500


# Main
if __name__ == "__main__":
    try:
        log_info(MODULE_NAME, "Starting Flask application")
        app.run(debug=True)
    except Exception as e:
        log_error(MODULE_NAME, e, "Fatal error in Flask application")
        raise
