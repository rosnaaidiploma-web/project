# AI-Driven Integrated HRM Framework

## Project Overview
This project is an end-to-end AI-driven HR management system built with Python, machine learning, NLP, and Flask. It automates recruitment, resume analysis, skill gap detection, employee promotion evaluation, training recommendations, chatbot support, and PDF report generation.

## Folder Structure
- `data/` : Sample datasets for resumes, employees, and job roles
- `models/` : Serialized machine learning model files
- `notebooks/` : Jupyter notebook for workflow and demonstration
- `src/` : Core Python modules for preprocessing, resume analysis, ML, and reporting
- `web_app/` : Flask web application with UI templates and static assets
- `reports/` : Generated PDF reports and export examples
- `chatbot/` : NLP chatbot intents dataset

## Installation
1. Open VS Code and open this folder: `c:\Users\Public\Documents\rosna`
2. Open a terminal in VS Code.
3. Install dependencies:

```powershell
C:/Users/ADMIN/AppData/Local/Programs/Python/Python314/python.exe -m pip install -r web_app/requirements.txt
```

4. Download NLTK data (only once):

```powershell
C:/Users/ADMIN/AppData/Local/Programs/Python/Python314/python.exe -c "import nltk; nltk.download('punkt'); nltk.download('stopwords'); nltk.download('wordnet'); nltk.download('averaged_perceptron_tagger')"
```

## Usage
1. Preprocess data and train models:

```powershell
C:/Users/ADMIN/AppData/Local/Programs/Python/Python314/python.exe src/run_pipeline.py
```

2. Start the Flask web app:

```powershell
C:/Users/ADMIN/AppData/Local/Programs/Python/Python314/python.exe web_app/app.py
```

3. Open a browser and go to `http://127.0.0.1:5000`

## Features
- Data cleaning, missing value handling, and text normalization
- Resume analyzer with TF-IDF job matching
- Skill gap detection and recommendation system
- Candidate selection ML model with Logistic Regression, Random Forest, and SVM
- Employee promotion readiness analysis
- Training course suggestions based on missing skills
- NLP chatbot for HR queries, resume help, and promotion guidance
- Flask web UI with candidate and HR dashboards
- PDF report generation with ReportLab

## Notes
- The model file `models/model.pkl` is created after running `src/run_pipeline.py`.
- Use the candidate dashboard to upload a resume text or try sample jobs.
- Use the HR dashboard to inspect reports and retrain the model.
