# Quick Start Guide - Enhanced HRM System with Error Handling

## 🚀 Getting Started (5 Minutes)

This guide will get you up and running with the AI-Driven HRM System including comprehensive error handling and logging.

---

## 📋 Prerequisites

- Python 3.8 or higher
- pip (Python package manager)
- ~500MB disk space

---

## 1️⃣ Installation

### Step 1: Install Dependencies

Open VS Code terminal and run:

```bash
# Install required packages
pip install -r requirements.txt
```

**Expected output:**
```
Successfully installed pandas scikit-learn flask reportlab nltk...
```

### Step 2: Verify Installation

```bash
# Check Python version
python --version
# Should show: Python 3.x.x

# Check packages
pip list | grep -E "pandas|scikit-learn|flask|nltk"
```

---

## 2️⃣ First Run - Training the Model

### Step 1: Run Training Pipeline

```bash
# Navigate to project root
cd /path/to/rosna

# Run the complete pipeline
python -m src.run_pipeline
```

**Expected output:**
```
============================================================
✅ HRM TRAINING PIPELINE COMPLETED SUCCESSFULLY
============================================================
📊 Model saved at: .../models/model.pkl
📁 Reports saved at: .../reports
📋 Logs saved at: .../logs/error.log
```

### Step 2: Check Logs for Errors

```bash
# View error log (if any)
cat logs/error.log

# Or in VS Code:
# Click on Explorer → logs → error.log
```

**What to look for:**
- ✓ INFO messages = Normal operation
- ⚠️ WARNING messages = Minor issues (still working)
- ❌ ERROR messages = Problems (see TROUBLESHOOTING_GUIDE.md)

---

## 3️⃣ Start Web Application

### Step 1: Launch Flask Server

```bash
# Start the web app
python web_app/app.py
```

**Expected output:**
```
 * Serving Flask app 'app'
 * Debug mode: on
 * Running on http://127.0.0.1:5000/
```

### Step 2: Open in Browser

Click this link or copy to browser:
```
http://localhost:5000
```

**You should see:** HRM System home page with job listings

---

## 4️⃣ Testing Features

### Test 1: Resume Analysis (Candidate)

1. Click **"Candidate Dashboard"**
2. Paste this sample resume:
```
John Developer

Skills: Python, Machine Learning, Data Analysis, SQL
Experience: 5

Education: Bachelor's in Computer Science
```

3. Select a job role from dropdown
4. Click **"Analyze Resume"**
5. Check results

**Expected:**
- ✓ Match percentage shown (0-100%)
- ✓ Skills comparison displayed
- ✓ Training recommendations listed
- ✓ PDF reports generated

**If error occurs:**
- Check `logs/error.log`
- Refer to TROUBLESHOOTING_GUIDE.md

---

### Test 2: Train Model (HR Dashboard)

1. Click **"HR Dashboard"**
2. Click **"Train Model"** button
3. Wait for training to complete (1-2 minutes)

**Expected:**
- ✓ "Model trained successfully!" message
- ✓ Accuracy shown (should be > 0.70)
- ✓ Model saved to `models/model.pkl`

**If training fails:**
- Check if dataset files exist:
  ```bash
  ls data/
  # Should show: old_resume_dataset.csv, job_dataset.csv, employee_dataset.csv
  ```
- View error log:
  ```bash
  tail logs/error.log
  ```

---

### Test 3: Chatbot

1. Click **"Chatbot"** from home page
2. Type: "What training should I take for machine learning?"
3. Submit

**Expected:**
- ✓ Chatbot responds with training suggestion
- ✓ Response is relevant to query

**If chatbot doesn't respond:**
- Verify `chatbot/intents.json` exists
- Check logs:
  ```bash
  grep "Chatbot" logs/error.log
  ```

---

## 5️⃣ Understanding Error Handling

### Error Log Location

```
logs/error.log  ← All system errors logged here
```

### Log Format

```
2024-04-27 10:30:45 - HRM_System - ERROR - [module.py:150] - function() - [ModuleName] Detailed error message
```

**Components:**
- **Timestamp**: When error occurred
- **Level**: DEBUG, INFO, WARNING, ERROR
- **File:Line**: Where error occurred
- **Function**: Which function had error
- **Module**: Which system module
- **Message**: Detailed description

### View Recent Errors

```bash
# Last 20 lines of log
tail -20 logs/error.log

# All errors only
grep ERROR logs/error.log

# Specific module errors
grep "ResumeAnalyzer" logs/error.log
```

---

## 6️⃣ Common Issues & Fixes

### Issue: "Model file not found"

**Error log shows:**
```
ERROR - [ml_model.py:250] - Model file not found at models/model.pkl
```

**Fix:**
```bash
# Train the model first
python -m src.run_pipeline
```

---

### Issue: "FileNotFoundError: data/job_dataset.csv"

**Error log shows:**
```
ERROR - [app.py:50] - File not found at data/job_dataset.csv
```

**Fix:**
```bash
# Verify data files exist
ls data/
# Should show all 3 CSV files
```

---

### Issue: "NLTK data not found"

**Error log shows:**
```
WARNING - [data_preprocessing.py:40] - Downloading NLTK data...
```

**This is normal!** System will auto-download NLTK data on first run.

---

### Issue: "Port 5000 already in use"

**Error message:**
```
OSError: [Errno 48] Address already in use
```

**Fix:**
```bash
# Kill process on port 5000
# Linux/Mac:
lsof -i :5000
kill -9 <PID>

# Or use different port:
# Edit web_app/app.py, line with: app.run(debug=True, port=5001)
```

---

## 7️⃣ Project Structure

```
rosna/
├── logs/
│   └── error.log                    ← ALL ERRORS LOGGED HERE
├── src/
│   ├── logger.py                    ← NEW: Logging system
│   ├── exceptions.py                ← NEW: Custom exceptions
│   ├── data_preprocessing.py        ← UPDATED: Error handling
│   ├── resume_analyzer.py           ← UPDATED: Error handling
│   ├── ml_model.py                  ← UPDATED: Error handling
│   ├── skill_gap.py                 ← UPDATED: Error handling
│   ├── promotion_analysis.py        ← UPDATED: Error handling
│   ├── training_recommender.py      ← UPDATED: Error handling
│   ├── chatbot.py                   ← UPDATED: Error handling
│   ├── pdf_report.py                ← UPDATED: Error handling
│   └── run_pipeline.py              ← UPDATED: Error handling
├── web_app/
│   ├── app.py                       ← UPDATED: Error handling
│   └── templates/
│       ├── 404.html                 ← NEW: Error page
│       └── 500.html                 ← NEW: Error page
├── data/
│   ├── old_resume_dataset.csv
│   ├── job_dataset.csv
│   └── employee_dataset.csv
├── models/
│   └── model.pkl                    ← Trained model (after first run)
├── reports/
│   ├── resume_report.pdf
│   ├── skill_gap_report.pdf
│   └── training_report.pdf
├── ERROR_HANDLING_GUIDE.md          ← NEW: Full error handling docs
├── TROUBLESHOOTING_GUIDE.md         ← NEW: Common errors & fixes
├── DEPLOYMENT_CHECKLIST.md          ← NEW: Pre-deployment checklist
└── QUICK_START.md                   ← This file
```

---

## 8️⃣ Documentation Files

| File | Purpose |
|------|---------|
| **ERROR_HANDLING_GUIDE.md** | Complete error handling architecture |
| **TROUBLESHOOTING_GUIDE.md** | Solutions to common problems |
| **DEPLOYMENT_CHECKLIST.md** | Pre-deployment verification |
| **logs/error.log** | Actual error logs from system |

---

## 9️⃣ Stopping the Application

### Method 1: Keyboard

```bash
# In VS Code terminal where server is running
Ctrl + C
```

### Method 2: Terminal

```bash
# Find Python process
ps aux | grep python

# Kill the process
kill -9 <PID>
```

---

## 🔟 Next Steps

### To Learn More:

1. **Error Handling Concepts**
   - Read: `ERROR_HANDLING_GUIDE.md`
   - Understand: Custom exceptions, logging patterns

2. **Troubleshooting**
   - Read: `TROUBLESHOOTING_GUIDE.md`
   - Know: Common errors and solutions

3. **Deployment**
   - Check: `DEPLOYMENT_CHECKLIST.md`
   - Verify: All components working

4. **View Logs**
   - Location: `logs/error.log`
   - Monitor: For errors and warnings

---

## ✅ Success Criteria

You've successfully set up the system when:

- ✅ `python -m src.run_pipeline` completes without crashing
- ✅ Web app starts: `python web_app/app.py`
- ✅ Home page loads at `http://localhost:5000`
- ✅ Resume analysis works
- ✅ Model trains successfully
- ✅ Chatbot responds
- ✅ `logs/error.log` exists (no critical errors)
- ✅ PDF reports generated
- ✅ All error handlers working

---

## 🆘 Need Help?

1. **Check logs first:**
   ```bash
   tail -50 logs/error.log
   ```

2. **Consult guides:**
   - ERROR_HANDLING_GUIDE.md
   - TROUBLESHOOTING_GUIDE.md

3. **Verify setup:**
   - Use DEPLOYMENT_CHECKLIST.md

4. **Debug step-by-step:**
   - Test individual modules
   - Add print statements
   - Use VS Code debugger (F5)

---

## 📊 System Architecture with Error Handling

```
User Input
    ↓
┌─────────────────────────────────────┐
│ Input Validation & Sanitization     │
│ (Catch invalid data early)          │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ Processing Modules                  │
│ (Try-except in every function)      │
│ - Data preprocessing               │
│ - Resume analysis                  │
│ - Model prediction                 │
│ - Report generation                │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ Error Handling                      │
│ (Custom exceptions caught)          │
│ - Log error details                │
│ - Return safe output               │
│ - Show user-friendly message       │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ Logging System                      │
│ (Persistent error tracking)         │
│ → logs/error.log                   │
│ → Console output                   │
└─────────────────────────────────────┘
    ↓
User Output (with error messages if needed)
```

---

## 🎓 Learning Path

**Week 1:**
- Run the system
- Explore features
- Check logs

**Week 2:**
- Read ERROR_HANDLING_GUIDE.md
- Understand error patterns
- Review error logs

**Week 3:**
- Study custom exceptions
- Review error handling code
- Test error scenarios

**Week 4:**
- Deploy with confidence
- Monitor in production
- Refine error messages

---

**Ready to start?** Run this command now:

```bash
python -m src.run_pipeline
```

---

**Version:** 1.0  
**Last Updated:** April 27, 2024  
**Status:** Production Ready
